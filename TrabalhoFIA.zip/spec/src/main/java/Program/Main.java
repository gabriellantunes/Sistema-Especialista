package Program;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Random;

public class Main {
    public static void main(String[] args) { //vamos trabalhar com 8 generos de filmes(os principais)
        JFrame frame = new JFrame("Sistema Especialista de Filmes");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 300);

        JPanel panel = new JPanel(new GridBagLayout());
        frame.add(panel);

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        constraints.weightx = 1;
        constraints.weighty = 1;
        constraints.anchor = GridBagConstraints.CENTER;

        JLabel welcomeLabel = new JLabel("Seja bem vindo ao IndicaFlix !!"); //Nao tive ideia melhor para nomes de sistemas especialista em filmes
        panel.add(welcomeLabel, constraints);

        constraints.gridy = 1;
        JLabel infoLabel = new JLabel("De acordo com as suas respostas o IndicaFlix irá lhe indicar algum filme para assistir.");
        panel.add(infoLabel, constraints);

        constraints.gridy = 2;
        JLabel funLabel = new JLabel("Não esqueça de se divertir !!");
        panel.add(funLabel, constraints);

        constraints.gridy = 3;
        JButton button = new JButton("Enviar");
        panel.add(button, constraints);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame genreFrame = new JFrame("Escolha o gênero");
                genreFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                genreFrame.setSize(600, 300);

                JPanel genrePanel = new JPanel(new BorderLayout());
                genreFrame.add(genrePanel);

                JLabel questionLabel = new JLabel("Qual o gênero do filme que deseja assistir?", SwingConstants.CENTER);
                genrePanel.add(questionLabel, BorderLayout.NORTH);

                String[] genres = {"Ação", "Comédia", "Drama", "Romance", "Documentário", "Suspense", "Terror", "Ficção Científica"};

                ButtonGroup group = new ButtonGroup();
                JPanel buttonsPanel = new JPanel();
                buttonsPanel.setLayout(new BoxLayout(buttonsPanel, BoxLayout.PAGE_AXIS));
                buttonsPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

                JRadioButton[] buttons = new JRadioButton[genres.length];
                for (int i = 0; i < genres.length; i++) {
                    buttons[i] = new JRadioButton(genres[i]);
                    buttons[i].setAlignmentX(Component.CENTER_ALIGNMENT);
                    buttonsPanel.add(buttons[i]);
                    group.add(buttons[i]);
                }
                genrePanel.add(buttonsPanel, BorderLayout.CENTER);

                JButton sendButton = new JButton("Enviar");
                genrePanel.add(sendButton, BorderLayout.SOUTH);

                genreFrame.setLocationRelativeTo(null);
                genreFrame.setVisible(true);

                frame.dispose();

                sendButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String selectedGenre = null;
                        for (Enumeration<AbstractButton> buttons = group.getElements(); buttons.hasMoreElements();) {
                            AbstractButton button = buttons.nextElement();

                            if (button.isSelected()) {
                                selectedGenre = button.getText();
                            }
                        }

                        if (selectedGenre != null) {
                            if (selectedGenre.equals("Ação")) {
                                JFrame actionFrame = new JFrame("Gênero Escolhido: Ação");
                                actionFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                actionFrame.setSize(600, 300);

                                JPanel actionPanel = new JPanel(new BorderLayout());
                                actionFrame.add(actionPanel);

                                JLabel questionLabel = new JLabel("Você prefere filmes mais antigos deste gênero ? ou mais recentes ?", SwingConstants.CENTER);
                                actionPanel.add(questionLabel, BorderLayout.NORTH);

                                ButtonGroup actionGroup = new ButtonGroup();
                                JRadioButton oldButton = new JRadioButton("Mais antigo");
                                JRadioButton newButton = new JRadioButton("Mais recente");
                                actionGroup.add(oldButton);
                                actionGroup.add(newButton);

                                JPanel radioPanel = new JPanel();
                                radioPanel.add(oldButton);
                                radioPanel.add(newButton);

                                actionPanel.add(radioPanel, BorderLayout.CENTER);

                                JButton sendButton = new JButton("Enviar");
                                actionPanel.add(sendButton, BorderLayout.SOUTH);

                                actionFrame.setLocationRelativeTo(null);
                                actionFrame.setVisible(true);

                                genreFrame.dispose(); // Aqui fecha a janela anterior

                                sendButton.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        if (oldButton.isSelected()) {
                                            // Filmes de ação mais antigos.
                                            if (oldButton.isSelected()) {
                                                JFrame oldActionFrame = new JFrame("Gênero Escolhido: Ação - Mais Antigo");
                                                oldActionFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                oldActionFrame.setSize(600, 300);

                                                JPanel oldActionPanel = new JPanel(new BorderLayout());
                                                oldActionFrame.add(oldActionPanel);

                                                JLabel questionLabel = new JLabel("Prefere filmes de ação mais antigos bem avaliados (IMDb alto)?", SwingConstants.CENTER); //caso nao selecionado as opções, sera considerado o valor "Sim"
                                                oldActionPanel.add(questionLabel, BorderLayout.NORTH);

                                                ButtonGroup oldActionGroup = new ButtonGroup();
                                                JRadioButton yesButton = new JRadioButton("Sim");
                                                JRadioButton dontMindButton = new JRadioButton("Não me importo");
                                                oldActionGroup.add(yesButton);
                                                oldActionGroup.add(dontMindButton);

                                                JPanel radioPanel = new JPanel();
                                                radioPanel.add(yesButton);
                                                radioPanel.add(dontMindButton);

                                                oldActionPanel.add(radioPanel, BorderLayout.CENTER);

                                                JButton sendButton = new JButton("Enviar");
                                                oldActionPanel.add(sendButton, BorderLayout.SOUTH);

                                                oldActionFrame.setLocationRelativeTo(null);  // Centraliza a janela na tela
                                                oldActionFrame.setVisible(true);

                                                actionFrame.dispose();

                                                sendButton.addActionListener(new ActionListener() {
                                                    @Override
                                                    public void actionPerformed(ActionEvent e) {
                                                        JFrame recommendFrame = new JFrame("Recomendação de Filme");
                                                        recommendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                        recommendFrame.setSize(700, 400);

                                                        JPanel recommendPanel = new JPanel(new BorderLayout());
                                                        recommendFrame.add(recommendPanel);

                                                        String[] movieList = {"Pulp Fiction", "Die Hard", "The Dark Knight", "Os Bons Companheiros", "Indiana Jones: Os Caçadores da Arca Perdida", "The Matrix"};
                                                        String[] movieSynopsis = {"Assassino que trabalha para a máfia se apaixona pela esposa de seu chefe quando é convidado a acompanhá-la, um boxeador descumpre sua promessa de perder uma luta e um casal tenta um assalto que rapidamente sai do controle.", "John McClane, agente do departamento de polícia de Nova York, tenta salvar sua esposa, Holly Gennaro, e outras pessoas que o terrorista alemão Hans Gruber tomou como reféns durante a festa de Natal no Nakatomi Plaza, em Los Angeles.", "Com a ajuda de Jim Gordon e Harvey Dent, Batman tem mantido a ordem na cidade de Gotham. Mas um jovem e anárquico criminoso, conhecido como Coringa, pretende testar o justiceiro e mergulhar a cidade em um verdadeiro caos.", "Henry Hill(Ray Liotta) conta a sua história de garoto do Brooklyn, Nova York, que sempre sonhou ser gângster, começando sua \"carreira\" aos 11 anos e se tornando protegido de James \"Jimmy\" Conway (Robert De Niro), um mafioso em ascensão. Tratado como filho por mais de vinte anos, ele se envolve em golpes cada vez maiores e acaba se casando com Karen Hill (Loraine Bracco), sua amante.", "O arqueólogo Indiana Jones precisa encontrar a Arca da Aliança, uma relíquia bíblica que contém os dez mandamentos. Como o portador do artefato se torna invencível, os nazistas também vão fazer de tudo para adquirir esse precioso objeto.", "Um hacker aprende com os misteriosos rebeldes sobre a verdadeira natureza de sua realidade e seu papel na guerra contra seus controladores."};
                                                        String[] movieImages = {
                                                                "/movies/acao/antigos/pulpfiction.jpg",
                                                                "/movies/acao/antigos/diehard.jpg",
                                                                "/movies/acao/antigos/darkknight.jpg",
                                                                "/movies/acao/antigos/goodfellas.jpg",
                                                                "/movies/acao/antigos/indiana.jpg",
                                                                "/movies/acao/antigos/matrix.jpg"
                                                        };

                                                        Random rand = new Random();
                                                        int randomIndex = rand.nextInt(movieList.length);

                                                        JLabel recommendLabel = new JLabel("A recomendação que damos para você é", SwingConstants.CENTER);
                                                        recommendPanel.add(recommendLabel, BorderLayout.NORTH);

                                                        JLabel movieLabel = new JLabel(movieList[randomIndex], SwingConstants.CENTER);
                                                        recommendPanel.add(movieLabel, BorderLayout.WEST);

                                                        JTextArea movieSynopsisArea = new JTextArea(movieSynopsis[randomIndex]);
                                                        movieSynopsisArea.setLineWrap(true);
                                                        movieSynopsisArea.setWrapStyleWord(true);
                                                        movieSynopsisArea.setEditable(false);
                                                        recommendPanel.add(movieSynopsisArea, BorderLayout.CENTER);

                                                        try {
                                                            URL movieImageUrl = getClass().getResource(movieImages[randomIndex]);
                                                            BufferedImage movieImage = ImageIO.read(movieImageUrl);
                                                            JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                            recommendPanel.add(picLabel, BorderLayout.EAST);
                                                        } catch (IOException ex) {
                                                            ex.printStackTrace();
                                                        }

                                                        recommendFrame.setLocationRelativeTo(null);
                                                        recommendFrame.setVisible(true);

                                                        oldActionFrame.dispose();
                                                    }
                                                });
                                            }
                                        } else if (newButton.isSelected()) {
                                            JFrame actionRecentFrame = new JFrame("Gênero Escolhido: Ação - Mais Recente");
                                            actionRecentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                            actionRecentFrame.setSize(600, 300);

                                            JPanel actionRecentPanel = new JPanel(new BorderLayout());
                                            actionRecentFrame.add(actionRecentPanel);

                                            JLabel questionLabel = new JLabel("Prefere filmes de ação mais recentes bem avaliados(IMDb alto)?", SwingConstants.CENTER); //caso nao selecionado as opções, sera considerado o valor "Sim"
                                            actionRecentPanel.add(questionLabel, BorderLayout.NORTH);

                                            ButtonGroup actionRecentGroup = new ButtonGroup();
                                            JRadioButton yesButton = new JRadioButton("Sim");
                                            JRadioButton dontMindButton = new JRadioButton("Não me importo");
                                            actionRecentGroup.add(yesButton);
                                            actionRecentGroup.add(dontMindButton);

                                            JPanel radioPanel = new JPanel();
                                            radioPanel.add(yesButton);
                                            radioPanel.add(dontMindButton);

                                            actionRecentPanel.add(radioPanel, BorderLayout.CENTER);

                                            JButton sendButton = new JButton("Enviar");
                                            actionRecentPanel.add(sendButton, BorderLayout.SOUTH);

                                            actionRecentFrame.setLocationRelativeTo(null);
                                            actionRecentFrame.setVisible(true);

                                            actionFrame.dispose();

                                            sendButton.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    JFrame recommendFrame = new JFrame("Recomendação de Filme");
                                                    recommendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                    recommendFrame.setSize(700, 400);

                                                    JPanel recommendPanel = new JPanel(new BorderLayout());
                                                    recommendFrame.add(recommendPanel);

                                                    String[] movieList = {"Top Gun: Maverick", "O Homem do Norte", "Trem-Bala", "O Peso do Talento", "John Wick", "Doutor Estranho no Multiverso da Loucura", "Mad Max"};
                                                    String[] movieSynopsis = {"Depois de mais de 30 anos de serviço como um dos principais aviadores da Marinha, Pete \"Maverick\" Mitchell está de volta, rompendo os limites como um piloto de testes corajoso. No mundo contemporâneo das guerras tecnológicas, Maverick enfrenta drones e prova que o fator humano ainda é essencial.", "O Príncipe Amleth está prestes a se tornar um homem quando seu tio assassina seu pai e sequestra sua mãe. Duas décadas depois, o jovem é agora um viking com a missão de salvar a mãe, matar o tio e vingar seu pai.", "Em um trem-bala indo rapidamente de Tóquio a Morioka, cinco assassinos profissionais descobrem que possuem o mesmo objetivo.", "O ator Nicolas Cage aceita relutantemente a oferta de um milhão de dólares para ficar na ilha de luxo de um superfã para sua festa de aniversário, mas as coisas tomam um rumo inesperado e ele acaba em uma aventura de um de seus filmes de ação.", "John Wick é uma franquia de mídia de suspense e ação neo-noir americana criada pelo roteirista Derek Kolstad e estrelada por Keanu Reeves como John Wick, um ex-assassino que é forçado a voltar ao submundo do crime que havia abandonado", "O aguardado filme trata da jornada do Doutor Estranho rumo ao desconhecido. Além de receber ajuda de novos aliados místicos e outros já conhecidos do público, o personagem atravessa as realidades alternativas incompreensíveis e perigosas do Multiverso para enfrentar um novo e misterioso adversário.", "Em um mundo pós-apocalíptico, Max Rockatansky acredita que a melhor forma de sobreviver é não depender de ninguém. Porém, após ser capturado pelo tirano Immortan Joe e seus rebeldes, Max se vê no meio de uma guerra mortal iniciada pela Imperatriz Furiosa, que tenta salvar um grupo de garotas. Também tentando fugir, Max aceita ajudá-la."};
                                                    /*String[] movieImages = {"..\\spec\\movies\\acao\\recentes\\topgun.jpg", "..\\spec\\movies\\acao\\recentes\\ohomemdonorte.jpg", "..\\spec\\movies\\acao\\recentes\\trembala.jpg", "..\\spec\\movies\\acao\\recentes\\opesodotalento.jpg", "..\\spec\\movies\\acao\\recentes\\johnwick.jpg", "..\\spec\\movies\\acao\\recentes\\doutorestranho.jpg", "..\\spec\\movies\\acao\\recentes\\madmax.jpg"};*/
                                                    String[] movieImages = {
                                                                "/movies/acao/recentes/topgun.jpg",
                                                                "/movies/acao/recentes/ohomemdonorte.jpg",
                                                                "/movies/acao/recentes/trembala.jpg",
                                                                "/movies/acao/recentes/opesodotalento.jpg",
                                                                "/movies/acao/recentes/johnwick.jpg",
                                                                "/movies/acao/recentes/doutorestranho.jpg",
                                                                "/movies/acao/recentes/madmax.jpg"
                                                    };

                                                    Random rand = new Random();
                                                    int randomIndex = rand.nextInt(movieList.length);

                                                    JLabel recommendLabel = new JLabel("A recomendação que damos para você é", SwingConstants.CENTER);
                                                    recommendPanel.add(recommendLabel, BorderLayout.NORTH);

                                                    JLabel movieLabel = new JLabel(movieList[randomIndex], SwingConstants.CENTER);
                                                    recommendPanel.add(movieLabel, BorderLayout.WEST);

                                                    JTextArea movieSynopsisArea = new JTextArea(movieSynopsis[randomIndex]);
                                                    movieSynopsisArea.setLineWrap(true);
                                                    movieSynopsisArea.setWrapStyleWord(true);
                                                    movieSynopsisArea.setEditable(false);
                                                    recommendPanel.add(movieSynopsisArea, BorderLayout.CENTER);

                                                    try {
                                                        URL movieImageUrl = getClass().getResource(movieImages[randomIndex]);
                                                        BufferedImage movieImage = ImageIO.read(movieImageUrl);
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    /*
                                                    try {
                                                        BufferedImage movieImage = ImageIO.read(new File(movieImages[randomIndex]));
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                     */
                                                    recommendFrame.setLocationRelativeTo(null);
                                                    recommendFrame.setVisible(true);

                                                    actionRecentFrame.dispose();
                                                }
                                            });
                                        }
                                    }
                                });
                            } else if (selectedGenre.equals("Comédia")) {
                                JFrame comedyFrame = new JFrame("Gênero Escolhido: Comédia");
                                comedyFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                comedyFrame.setSize(600, 300);

                                JPanel comedyPanel = new JPanel(new BorderLayout());
                                comedyFrame.add(comedyPanel);

                                JLabel questionLabel = new JLabel("Você prefere filmes de comédia mais antigos ou mais recentes ?", SwingConstants.CENTER);
                                comedyPanel.add(questionLabel, BorderLayout.NORTH);

                                ButtonGroup comedyGroup = new ButtonGroup();
                                JRadioButton oldButton = new JRadioButton("Mais antigo");
                                JRadioButton newButton = new JRadioButton("Mais recente");
                                comedyGroup.add(oldButton);
                                comedyGroup.add(newButton);

                                JPanel radioPanel = new JPanel();
                                radioPanel.add(oldButton);
                                radioPanel.add(newButton);

                                comedyPanel.add(radioPanel, BorderLayout.CENTER);

                                JButton sendButton = new JButton("Enviar");
                                comedyPanel.add(sendButton, BorderLayout.SOUTH);

                                comedyFrame.setLocationRelativeTo(null);
                                comedyFrame.setVisible(true);

                                genreFrame.dispose();

                                sendButton.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        if (oldButton.isSelected()) {
                                            // Filmes de comédia mais antigos.
                                            JFrame comedyOldFrame = new JFrame("Gênero Escolhido: Comédia - Mais Antigo");
                                            comedyOldFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                            comedyOldFrame.setSize(600, 300);

                                            JPanel comedyOldPanel = new JPanel(new BorderLayout());
                                            comedyOldFrame.add(comedyOldPanel);

                                            JLabel questionLabel = new JLabel("Prefere filmes de comédia mais antigos bem avaliados(IMDb alto)?", SwingConstants.CENTER); //caso nao selecionado as opções, sera considerado o valor "Sim"
                                            comedyOldPanel.add(questionLabel, BorderLayout.NORTH);

                                            ButtonGroup comedyOldGroup = new ButtonGroup();
                                            JRadioButton yesButton = new JRadioButton("Sim");
                                            JRadioButton dontMindButton = new JRadioButton("Não me importo");
                                            comedyOldGroup.add(yesButton);
                                            comedyOldGroup.add(dontMindButton);

                                            JPanel radioPanel = new JPanel();
                                            radioPanel.add(yesButton);
                                            radioPanel.add(dontMindButton);

                                            comedyOldPanel.add(radioPanel, BorderLayout.CENTER);

                                            JButton sendButton = new JButton("Enviar");
                                            comedyOldPanel.add(sendButton, BorderLayout.SOUTH);

                                            comedyOldFrame.setLocationRelativeTo(null);
                                            comedyOldFrame.setVisible(true);

                                            comedyFrame.dispose();

                                            sendButton.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    JFrame recommendFrame = new JFrame("Recomendação de Filme");
                                                    recommendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                    recommendFrame.setSize(700, 400);

                                                    JPanel recommendPanel = new JPanel(new BorderLayout());
                                                    recommendFrame.add(recommendPanel);

                                                    String[] movieList = {"A Fuga das Galinhas", "O Gosto dos Outros", "Quanto Mais Quente Melhor", "Se Meu Apartamento Falasse", "Tiros na Broadway", "Feitiço do Tempo", "As Branquelas"};
                                                    String[] movieSynopsis = {"No galinheiro de uma fazenda inglesa dos anos 1950, galinhas cumprem sua função e vivem pacatamente sonhando com uma vida melhor. Uma delas, Ginger, sonha com a liberdade e planeja sair voando dali junto com suas companheiras.", "Castella (Jean-Pierre Bacri) é um homem de negócios bem-sucedido em uma pequena cidade no interior da França. Certa noite, ele vai com sua esposa Angélique (Christiane Millet) assistir a uma produção local da peça Berenice, de Racine, na qual sua filha faz um papel. Encantado por Clara (Anne Alvaro), a atriz principal, que havia sido sua professora de inglês no passado, Castella a contrata novamente. Enquanto isso, Manie (Agnès Jaoui), uma amiga de Clara, é uma garçonete que aumenta seus ganhos fazendo tráfico de haxixe. Ela é uma mulher bem-humorada e independente, porém complexada por fracassos amorosos anteriores. Manie tenta de tudo para que seu atual compromisso dê certo, mas sabe que não será tão fácil.", "Após testemunhar um assassinato da máfia, o saxofonista Joe e seu velho amigo Jerry improvisam um plano rápido para escaparem vivos de Chicago. Disfarçando-se como mulheres, eles se juntam a uma banda de jazz onde todos os membros são do sexo feminino e pegam um trem com destino à ensolarada Flórida.", "O funcionário Bud Baxter empresta o apartamento para que seu chefe tenha encontros com a amante. Ao descobrir que a amante do chefe é a garota por quem está apaixonado, ele precisa decidir entre a mulher que ama e sua carreira.", "Nos anos 20, um autor teatral de Nova York tem sua peça patrocinada por um gângster, mas o diretor é obrigado a escalar a namorada sem talento do mafioso como atriz.", "Phil, um arrogante meteorologista de um canal de televisão, fica preso em uma espécie de túnel do tempo, condenado a reviver indefinidamente o mesmo dia até que mude suas atitudes.","Dois irmãos agentes do FBI, Marcus e Kevin Copeland, acidentalmente evitam que bandidos sejam presos em uma apreensão de drogas. Como castigo, eles são forçados a escoltar um par de socialites nos Hamptons. Quando as meninas descobrem o plano da agência, elas se recusam a ir. Sem opções, Marcus e Kevin, dois homens negros, decidem fingir que são as irmãs e se transformam em um par de loiras."};
                                                    /*String[] movieImages = {"..\\spec\\movies\\comedia\\antigos\\afugadasgalinhas.jpg", "..\\spec\\movies\\comedia\\antigos\\ogostodosoutros.jpg", "..\\spec\\movies\\comedia\\antigos\\quantomaisquentemelhor.jpg", "..\\spec\\movies\\comedia\\antigos\\semeuapefalasse.jpg", "..\\spec\\movies\\comedia\\antigos\\tirosnabroadway.jpg", "..\\spec\\movies\\comedia\\antigos\\feiticodotempo.jpg", "..\\spec\\movies\\comedia\\antigos\\asbranquelas.jpg"};*/
                                                    String[] movieImages = {
                                                            "/movies/comedia/antigos/afugadasgalinhas.jpg",
                                                            "/movies/comedia/antigos/ogostodosoutros.jpg",
                                                            "/movies/comedia/antigos/quantomaisquentemelhor.jpg",
                                                            "/movies/comedia/antigos/semeuapefalasse.jpg",
                                                            "/movies/comedia/antigos/tirosnabroadway.jpg",
                                                            "/movies/comedia/antigos/feiticodotempo.jpg",
                                                            "/movies/comedia/antigos/asbranquelas.jpg"
                                                    };

                                                    Random rand = new Random();
                                                    int randomIndex = rand.nextInt(movieList.length);

                                                    JLabel recommendLabel = new JLabel("Recomendamos o seguinte filme para você:", SwingConstants.CENTER);
                                                    recommendPanel.add(recommendLabel, BorderLayout.NORTH);

                                                    JLabel movieLabel = new JLabel(movieList[randomIndex], SwingConstants.CENTER);
                                                    recommendPanel.add(movieLabel, BorderLayout.WEST);

                                                    JTextArea movieSynopsisArea = new JTextArea(movieSynopsis[randomIndex]);
                                                    movieSynopsisArea.setLineWrap(true);
                                                    movieSynopsisArea.setWrapStyleWord(true);
                                                    movieSynopsisArea.setEditable(false);
                                                    recommendPanel.add(movieSynopsisArea, BorderLayout.CENTER);

                                                    try {
                                                        URL movieImageUrl = getClass().getResource(movieImages[randomIndex]);
                                                        BufferedImage movieImage = ImageIO.read(movieImageUrl);
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    /*
                                                    try {
                                                        BufferedImage movieImage = ImageIO.read(new File(movieImages[randomIndex]));
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    */
                                                    recommendFrame.setLocationRelativeTo(null);
                                                    recommendFrame.setVisible(true);

                                                    comedyOldFrame.dispose();
                                                }
                                            });
                                            // ...
                                        } else if (newButton.isSelected()) {
                                            JFrame comedyRecentFrame = new JFrame("Gênero Escolhido: Comédia - Mais Recente");
                                            comedyRecentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                            comedyRecentFrame.setSize(600, 300);

                                            JPanel comedyRecentPanel = new JPanel(new BorderLayout());
                                            comedyRecentFrame.add(comedyRecentPanel);

                                            JLabel questionLabel = new JLabel("Prefere filmes de comédia mais recentes bem avaliados(IMDb alto)?", SwingConstants.CENTER); //caso nao selecionado as opções, sera considerado o valor "Sim"
                                            comedyRecentPanel.add(questionLabel, BorderLayout.NORTH);

                                            ButtonGroup comedyRecentGroup = new ButtonGroup();
                                            JRadioButton yesButton = new JRadioButton("Sim");
                                            JRadioButton dontMindButton = new JRadioButton("Não me importo");
                                            comedyRecentGroup.add(yesButton);
                                            comedyRecentGroup.add(dontMindButton);

                                            JPanel radioPanel = new JPanel();
                                            radioPanel.add(yesButton);
                                            radioPanel.add(dontMindButton);

                                            comedyRecentPanel.add(radioPanel, BorderLayout.CENTER);

                                            JButton sendButton = new JButton("Enviar");
                                            comedyRecentPanel.add(sendButton, BorderLayout.SOUTH);

                                            comedyRecentFrame.setLocationRelativeTo(null);
                                            comedyRecentFrame.setVisible(true);

                                            comedyFrame.dispose();

                                            sendButton.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    JFrame recommendFrame = new JFrame("Recomendação de Filme");
                                                    recommendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                    recommendFrame.setSize(700, 400);

                                                    JPanel recommendPanel = new JPanel(new BorderLayout());
                                                    recommendFrame.add(recommendPanel);

                                                    String[] movieList = {"Um Parto de Viagem", "O Homem de Toronto", "De Férias da Família", "O Peso do Talento", "Cidade Perdida", "Alerta Vermelho", "Dog - A Aventura de uma vida"};
                                                    String[] movieSynopsis = {"Peter Highman é um ansioso pai de primeira viagem cuja esposa está a cinco dias de dar à luz. Peter corre contra o tempo para conseguir um voo de volta para Atlanta a tempo de chegar para o parto, mas seus planos são atrapalhados quando ele conhece o aspirante a ator Ethan Tremblay. O encontro força Peter a pegar carona com Ethan e atravessar o país.", "Um caso de identidade trocada obriga um homem comum a se unir a um famoso assassino na esperança de continuar vivo.", "De férias sem a família pela primeira vez em anos, um pai dedicado parte para o aniversário alucinante de um velho amigo festeiro.", "O ator Nicolas Cage aceita relutantemente a oferta de um milhão de dólares para ficar na ilha de luxo de um superfã para sua festa de aniversário, mas as coisas tomam um rumo inesperado e ele acaba em uma aventura de um de seus filmes de ação.", "A brilhante e reclusa autora Loretta Sage escreve romances populares de aventura, cujas capas são estreladas pelo belo modelo Alan. Durante a turnê de promoção de seu novo livro, Loretta é raptada.", "Um alerta vermelho da Interpol é emitido e o agente do FBI John Hartley assume o caso. Durante sua busca, ele se vê diante de um assalto ousado e é forçado a se aliar ao maior ladrão de arte da história, Nolan Booth, para capturar a ladra de arte mais procurada do mundo atualmente, Sarah Black.", "Com uma cadela chamada Lulu ao seu lado, o ex-soldado Briggs percorre a costa oeste americana para chegar ao funeral de um soldado a tempo. Ao longo do caminho, Briggs e Lulu enlouquecem um ao outro, quebram diversas leis, escapam da morte por pouco e aprendem a baixar a guarda para ter uma chance de encontrar a felicidade."};
                                                    /*String[] movieImages = {"..\\spec\\movies\\comedia\\recentes\\umpartodeviagem.jpg", "..\\spec\\movies\\comedia\\recentes\\ohomemdetoronto.jpg", "..\\spec\\movies\\comedia\\recentes\\deferiasdafamilia.jpg", "..\\spec\\movies\\comedia\\recentes\\opesodotalento.jpg", "..\\spec\\movies\\comedia\\recentes\\cidadperdida.jpg", "..\\spec\\movies\\comedia\\recentes\\alertavermelho.jpg", "..\\spec\\movies\\comedia\\recentes\\dog.jpg"};*/
                                                    String[] movieImages = {
                                                                "/movies/comedia/recentes/umpartodeviagem.jpg",
                                                                "/movies/comedia/recentes/ohomemdetoronto.jpg",
                                                                "/movies/comedia/recentes/deferiasdafamilia.jpg",
                                                                "/movies/comedia/recentes/opesodotalento.jpg",
                                                                "/movies/comedia/recentes/cidadperdida.jpg",
                                                                "/movies/comedia/recentes/alertavermelho.jpg",
                                                                "/movies/comedia/recentes/dog.jpg"
                                                    };

                                                    Random rand = new Random();
                                                    int randomIndex = rand.nextInt(movieList.length);

                                                    JLabel recommendLabel = new JLabel("Recomendamos este filme para você assistir:", SwingConstants.CENTER);
                                                    recommendPanel.add(recommendLabel, BorderLayout.NORTH);

                                                    JLabel movieLabel = new JLabel(movieList[randomIndex], SwingConstants.CENTER);
                                                    recommendPanel.add(movieLabel, BorderLayout.WEST);

                                                    JTextArea movieSynopsisArea = new JTextArea(movieSynopsis[randomIndex]);
                                                    movieSynopsisArea.setLineWrap(true);
                                                    movieSynopsisArea.setWrapStyleWord(true);
                                                    movieSynopsisArea.setEditable(false);
                                                    recommendPanel.add(movieSynopsisArea, BorderLayout.CENTER);

                                                    try {
                                                        URL movieImageUrl = getClass().getResource(movieImages[randomIndex]);
                                                        BufferedImage movieImage = ImageIO.read(movieImageUrl);
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    /*
                                                    try {
                                                        BufferedImage movieImage = ImageIO.read(new File(movieImages[randomIndex]));
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    */

                                                    recommendFrame.setLocationRelativeTo(null);
                                                    recommendFrame.setVisible(true);

                                                    comedyRecentFrame.dispose();
                                                }
                                            });
                                        }
                                    }
                                });
                            } else if (selectedGenre.equals("Drama")) {
                                JFrame dramaFrame = new JFrame("Gênero Escolhido: Drama");
                                dramaFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                dramaFrame.setSize(600, 300);

                                JPanel dramaPanel = new JPanel(new BorderLayout());
                                dramaFrame.add(dramaPanel);

                                JLabel questionLabel = new JLabel("Você prefere filmes de drama mais antigos ? ou mais recentes ?", SwingConstants.CENTER);
                                dramaPanel.add(questionLabel, BorderLayout.NORTH);

                                ButtonGroup dramaGroup = new ButtonGroup();
                                JRadioButton oldButton = new JRadioButton("Mais antigo");
                                JRadioButton newButton = new JRadioButton("Mais recente");
                                dramaGroup.add(oldButton);
                                dramaGroup.add(newButton);

                                JPanel radioPanel = new JPanel();
                                radioPanel.add(oldButton);
                                radioPanel.add(newButton);

                                dramaPanel.add(radioPanel, BorderLayout.CENTER);

                                JButton sendButton = new JButton("Enviar");
                                dramaPanel.add(sendButton, BorderLayout.SOUTH);

                                dramaFrame.setLocationRelativeTo(null);
                                dramaFrame.setVisible(true);

                                genreFrame.dispose();

                                sendButton.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        if (oldButton.isSelected()) {
                                            JFrame dramaOldFrame = new JFrame("Gênero Escolhido: Drama - Mais Antigo");
                                            dramaOldFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                            dramaOldFrame.setSize(600, 300);

                                            JPanel dramaOldPanel = new JPanel(new BorderLayout());
                                            dramaOldFrame.add(dramaOldPanel);

                                            JLabel questionLabel = new JLabel("Prefere filmes de drama mais antigos bem avaliados(IMDb alto)?", SwingConstants.CENTER); //caso nao selecionado as opções, sera considerado o valor "Sim"
                                            dramaOldPanel.add(questionLabel, BorderLayout.NORTH);

                                            ButtonGroup dramaOldGroup = new ButtonGroup();
                                            JRadioButton yesButton = new JRadioButton("Sim");
                                            JRadioButton dontMindButton = new JRadioButton("Não me importo");
                                            dramaOldGroup.add(yesButton);
                                            dramaOldGroup.add(dontMindButton);

                                            JPanel radioPanel = new JPanel();
                                            radioPanel.add(yesButton);
                                            radioPanel.add(dontMindButton);

                                            dramaOldPanel.add(radioPanel, BorderLayout.CENTER);

                                            JButton sendButton = new JButton("Enviar");
                                            dramaOldPanel.add(sendButton, BorderLayout.SOUTH);

                                            dramaOldFrame.setLocationRelativeTo(null);
                                            dramaOldFrame.setVisible(true);

                                            dramaFrame.dispose();

                                            sendButton.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    JFrame recommendFrame = new JFrame("Recomendação de Filme");
                                                    recommendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                    recommendFrame.setSize(700, 400);

                                                    JPanel recommendPanel = new JPanel(new BorderLayout());
                                                    recommendFrame.add(recommendPanel);

                                                    String[] movieList = {"Sempre ao seu Lado", "A Espera de um Milagre", "A Vida é Bela", "Show de Truman", "Uma Lição de Amor", "Forrest Gump - O Contador de Histórias", "Um Sonho de Liberdade", "Perfume de Mulher"};
                                                    String[] movieSynopsis = {
                                                            "Um professor universitário se afeiçoa a um cachorro abandonado que ele leva para casa. Entretanto, quando ele menos espera, o animal o ajuda a conseguir superar um grande trauma.",
                                                            "John Coffey é um gigante negro condenado à morte na cadeia local. Paul Edgecomb é o segurança responsável por ele e, ao longo dos anos, se encanta com as qualidades mágicas do prisioneiro.",
                                                            "Durante a Segunda Guerra Mundial na Itália, o judeu Guido (Roberto Benigni) e seu filho Giosué são levados para um campo de concentração nazista. Afastado de sua esposa, ele tem que usar sua criatividade para fazer o menino acreditar que estão participando de uma grande brincadeira, com o intuito de protegê-lo do terror e da violência que os cercam.",
                                                            "Truman Burbank é um vendedor de seguros que leva uma vida simples com sua esposa. Porém, sua vida vira de cabeça para baixo quando ele descobre que é o principal personagem de um programa de televisão transmitido 24 horas por dia.",
                                                            "Sam Dawson é um pai com deficiência mental que cuida de sua filha Lucy com a ajuda de seus amigos. Quando Lucy completa sete anos e começa a ultrapassar intelectualmente seu pai, o serviço social decide intervir e a situação se complica.",
                                                            "Forrest Gump é um homem com QI abaixo da média que, mesmo assim, consegue participar de momentos importantes da história dos Estados Unidos, como a Guerra do Vietnã e o caso Watergate.",
                                                            "Andy Dufresne é um banqueiro que é condenado por dois crimes de assassinato que não cometeu. Na prisão, ele faz amizade com Red, um prisioneiro influente, e juntos, eles sonham com a liberdade.",
                                                            "Um estudante universitário pobre que dirige carros de luxo no seu tempo livre é contratado para cuidar de um coronel cego, que não é uma pessoa muito agradável. No fim de semana de ação de graças, ele tem que acompanhar o coronel em uma viagem à cidade de Nova York."
                                                    };
                                                    /*String[] movieImages = {"..\\spec\\movies\\drama\\antigos\\sempreaoseulado.jpg", "..\\spec\\movies\\drama\\antigos\\aesperadeummilagre.jpg", "..\\spec\\movies\\drama\\antigos\\avidaebela.jpg", "..\\spec\\movies\\drama\\antigos\\showdetruman.jpg", "..\\spec\\movies\\drama\\antigos\\umalicaodeamor.jpg", "..\\spec\\movies\\drama\\antigos\\forrestgump.jpg", "..\\spec\\movies\\drama\\antigos\\umsonhodeliberdade.jpg", "..\\spec\\movies\\drama\\antigos\\perfumedemulher.jpg"};*/
                                                    String[] movieImages = {
                                                                "/movies/drama/antigos/sempreaoseulado.jpg",
                                                                "/movies/drama/antigos/aesperadeummilagre.jpg",
                                                                "/movies/drama/antigos/avidaebela.jpg",
                                                                "/movies/drama/antigos/showdetruman.jpg",
                                                                "/movies/drama/antigos/umalicaodeamor.jpg",
                                                                "/movies/drama/antigos/forrestgump.jpg",
                                                                "/movies/drama/antigos/umsonhodeliberdade.jpg",
                                                                "/movies/drama/antigos/perfumedemulher.jpg"
                                                    };

                                                    Random rand = new Random();
                                                    int randomIndex = rand.nextInt(movieList.length);

                                                    JLabel recommendLabel = new JLabel("A recomendação de filme que sugerimos para você é:", SwingConstants.CENTER);
                                                    recommendPanel.add(recommendLabel, BorderLayout.NORTH);

                                                    JLabel movieLabel = new JLabel(movieList[randomIndex], SwingConstants.CENTER);
                                                    recommendPanel.add(movieLabel, BorderLayout.WEST);

                                                    JTextArea movieSynopsisArea = new JTextArea(movieSynopsis[randomIndex]);
                                                    movieSynopsisArea.setLineWrap(true);
                                                    movieSynopsisArea.setWrapStyleWord(true);
                                                    movieSynopsisArea.setEditable(false);
                                                    recommendPanel.add(movieSynopsisArea, BorderLayout.CENTER);

                                                    try {
                                                        URL movieImageUrl = getClass().getResource(movieImages[randomIndex]);
                                                        BufferedImage movieImage = ImageIO.read(movieImageUrl);
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    /*
                                                    try {
                                                        BufferedImage movieImage = ImageIO.read(new File(movieImages[randomIndex]));
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                     */

                                                    recommendFrame.setLocationRelativeTo(null);
                                                    recommendFrame.setVisible(true);

                                                    dramaOldFrame.dispose();
                                                }
                                            });
                                        } else if (newButton.isSelected()) {
                                            JFrame dramaNewFrame = new JFrame("Gênero Escolhido: Drama - Mais Recente");
                                            dramaNewFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                            dramaNewFrame.setSize(600, 300);

                                            JPanel dramaNewPanel = new JPanel(new BorderLayout());
                                            dramaNewFrame.add(dramaNewPanel);

                                            JLabel questionLabel = new JLabel("Prefere filmes de drama mais recentes bem avaliados(IMDb alto)?", SwingConstants.CENTER); //caso nao selecionado as opções, sera considerado o valor "Sim"
                                            dramaNewPanel.add(questionLabel, BorderLayout.NORTH);

                                            ButtonGroup dramaNewGroup = new ButtonGroup();
                                            JRadioButton yesButton = new JRadioButton("Sim");
                                            JRadioButton dontMindButton = new JRadioButton("Não me importo");
                                            dramaNewGroup.add(yesButton);
                                            dramaNewGroup.add(dontMindButton);

                                            JPanel radioPanel = new JPanel();
                                            radioPanel.add(yesButton);
                                            radioPanel.add(dontMindButton);

                                            dramaNewPanel.add(radioPanel, BorderLayout.CENTER);

                                            JButton sendButton = new JButton("Enviar");
                                            dramaNewPanel.add(sendButton, BorderLayout.SOUTH);

                                            dramaNewFrame.setLocationRelativeTo(null);
                                            dramaNewFrame.setVisible(true);

                                            dramaFrame.dispose();

                                            sendButton.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    JFrame recommendFrame = new JFrame("Recomendação de Filme");
                                                    recommendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                    recommendFrame.setSize(700, 400);

                                                    JPanel recommendPanel = new JPanel(new BorderLayout());
                                                    recommendFrame.add(recommendPanel);

                                                    String[] movieList = {"Vidro", "Cidade de Asteroides", "Minha Culpa", "A Cinco Passos de Você", "A favorita", "Nomadland", "Nunca, Raramente, Às Vezes, Sempre", "Ford vs Ferrari"};
                                                    String[] movieSynopsis = {
                                                            "Depois de Fragmentado, Elijah Price, também conhecido como Mr. Glass, descobre que David Dunn está perseguindo a figura super-humana, A Besta. Na série de encontros que aumentam de intensidade, a sombria presença de Price emerge como um orquestrador que detém segredos críticos para ambos os homens.",
                                                            "Após um cataclismo devastar a atmosfera da Terra, a humanidade se refugiou nas cidades de asteróides. O detetive Richter é contratado para encontrar a filha desaparecida de um magnata rico.",
                                                            "Noah deixa sua cidade, namorado e amigas para se mudar para a mansão do novo marido da mãe. Lá conhece seu novo meio-irmão, Nick, e suas personalidades não batem desde o início. Mas a atração que sentem um pelo outro cresce imensamente.",
                                                            "Dois pacientes com fibrose cística se apaixonam enquanto passam muito tempo juntos no hospital. No entanto, a regra do hospital afirma que eles devem permanecer pelo menos seis pés um do outro para evitar a troca de bactérias.",
                                                            "Na Inglaterra do século XVIII, Sarah Churchill, a Duquesa de Marlborough, exerce sua influência na corte como confidente, conselheira e amante secreta da Rainha Ana. No entanto, sua posição é ameaçada pela chegada de sua prima, Abigail Masham, que logo se torna a favorita da rainha.",
                                                            "Uma mulher em seus sessenta anos, depois de perder tudo na Grande Recessão, embarca em uma jornada pelo Oeste Americano, vivendo como uma nômade moderna em uma van.",
                                                            "Duas primas adolescentes da Pensilvânia embarcam em uma jornada até a cidade de Nova York para buscar assistência médica após uma gravidez indesejada.",
                                                            "Baseado na incrível história real do visionário designer de automóveis americano Carroll Shelby e do destemido piloto britânico Ken Miles, que juntos construíram um carro de corrida revolucionário para a Ford Motor Company assumir o controle das pistas e derrotar o dominante carro de corrida Enzo Ferrari em Le Mans, na França, em 1966."
                                                    };
                                                    /*String[] movieImages = {"..\\spec\\movies\\drama\\recentes\\vidro.jpg", "..\\spec\\movies\\drama\\recentes\\cidadedeasteroides.jpg", "..\\spec\\movies\\drama\\recentes\\minhaculpa.jpg", "..\\spec\\movies\\drama\\recentes\\acinco.jpg", "..\\spec\\movies\\drama\\recentes\\afavorita.jpg", "..\\spec\\movies\\drama\\recentes\\nomadland.jpg", "..\\spec\\movies\\drama\\recentes\\nunca.jpg", "..\\spec\\movies\\drama\\recentes\\fordvsferrari.jpg"};*/

                                                    String[] movieImages = {
                                                                "/movies/drama/recentes/vidro.jpg",
                                                                "/movies/drama/recentes/cidadedeasteroides.jpg",
                                                                "/movies/drama/recentes/minhaculpa.jpg",
                                                                "/movies/drama/recentes/acinco.jpg",
                                                                "/movies/drama/recentes/afavorita.jpg",
                                                                "/movies/drama/recentes/nomadland.jpg",
                                                                "/movies/drama/recentes/nunca.jpg",
                                                                "/movies/drama/recentes/fordvsferrari.jpg"
                                                    };

                                                    Random rand = new Random();
                                                    int randomIndex = rand.nextInt(movieList.length);

                                                    JLabel recommendLabel = new JLabel("Recomendamos que você assista:", SwingConstants.CENTER);
                                                    recommendPanel.add(recommendLabel, BorderLayout.NORTH);

                                                    JLabel movieLabel = new JLabel(movieList[randomIndex], SwingConstants.CENTER);
                                                    recommendPanel.add(movieLabel, BorderLayout.WEST);

                                                    JTextArea movieSynopsisArea = new JTextArea(movieSynopsis[randomIndex]);
                                                    movieSynopsisArea.setLineWrap(true);
                                                    movieSynopsisArea.setWrapStyleWord(true);
                                                    movieSynopsisArea.setEditable(false);
                                                    recommendPanel.add(movieSynopsisArea, BorderLayout.CENTER);

                                                    try {
                                                        URL movieImageUrl = getClass().getResource(movieImages[randomIndex]);
                                                        BufferedImage movieImage = ImageIO.read(movieImageUrl);
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    /*
                                                    try {
                                                        BufferedImage movieImage = ImageIO.read(new File(movieImages[randomIndex]));
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    */
                                                    recommendFrame.setLocationRelativeTo(null);
                                                    recommendFrame.setVisible(true);

                                                    dramaNewFrame.dispose();
                                                }
                                            });
                                        }
                                    }
                                });
                            } else if (selectedGenre.equals("Romance")) {
                                JFrame romanceFrame = new JFrame("Gênero Escolhido: Romance");
                                romanceFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                romanceFrame.setSize(600, 300);

                                JPanel romancePanel = new JPanel(new BorderLayout());
                                romanceFrame.add(romancePanel);

                                JLabel questionLabel = new JLabel("Você prefere filmes de romance mais antigos ? ou mais recentes ?", SwingConstants.CENTER);
                                romancePanel.add(questionLabel, BorderLayout.NORTH);

                                ButtonGroup romanceGroup = new ButtonGroup();
                                JRadioButton oldButton = new JRadioButton("Mais antigos");
                                JRadioButton newButton = new JRadioButton("Mais recentes");
                                romanceGroup.add(oldButton);
                                romanceGroup.add(newButton);

                                JPanel radioPanel = new JPanel();
                                radioPanel.add(oldButton);
                                radioPanel.add(newButton);

                                romancePanel.add(radioPanel, BorderLayout.CENTER);

                                JButton sendButton = new JButton("Enviar");
                                romancePanel.add(sendButton, BorderLayout.SOUTH);

                                romanceFrame.setLocationRelativeTo(null);
                                romanceFrame.setVisible(true);

                                genreFrame.dispose();

                                sendButton.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        if (oldButton.isSelected()) {
                                            JFrame romanceOldFrame = new JFrame("Gênero Escolhido: Romance - Mais Antigo");
                                            romanceOldFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                            romanceOldFrame.setSize(600, 300);

                                            JPanel romanceOldPanel = new JPanel(new BorderLayout());
                                            romanceOldFrame.add(romanceOldPanel);

                                            JLabel questionLabel = new JLabel("Você prefere filmes de romance mais antigos bem avaliados (IMDb alto)?", SwingConstants.CENTER); //caso nao selecionado as opções, sera considerado o valor "Sim"
                                            romanceOldPanel.add(questionLabel, BorderLayout.NORTH);

                                            ButtonGroup romanceOldGroup = new ButtonGroup();
                                            JRadioButton yesButton = new JRadioButton("Sim");
                                            JRadioButton dontMindButton = new JRadioButton("Não me importo");
                                            romanceOldGroup.add(yesButton);
                                            romanceOldGroup.add(dontMindButton);

                                            JPanel radioPanel = new JPanel();
                                            radioPanel.add(yesButton);
                                            radioPanel.add(dontMindButton);

                                            romanceOldPanel.add(radioPanel, BorderLayout.CENTER);

                                            JButton sendButton = new JButton("Enviar");
                                            romanceOldPanel.add(sendButton, BorderLayout.SOUTH);

                                            romanceOldFrame.setLocationRelativeTo(null);
                                            romanceOldFrame.setVisible(true);

                                            romanceFrame.dispose();

                                            sendButton.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    JFrame recommendFrame = new JFrame("Recomendação de Filme");
                                                    recommendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                    recommendFrame.setSize(700, 400);

                                                    JPanel recommendPanel = new JPanel(new BorderLayout());
                                                    recommendFrame.add(recommendPanel);

                                                    String[] movieList = {"As pontes de Madison", "Adivinhe quem vem para o jantar", "Tarde demais para esquecer", "Enquanto você dormir", "Love Story - Uma história de amor", "Casablanca", "Maurice"};
                                                    String[] movieSynopsis = {
                                                            "História de amor comovente sobre um fotógrafo da revista National Geographic, incumbido de fotografar as pontes de Madison, em Iowa. Lá, ele conhece uma dona de casa, cujo marido e filhos estão viajando. Os dois vivem um breve e intenso romance entre duas almas gêmeas que se conheceram tarde demais.",
                                                            "Joanna Drayton, uma socialite, retorna para casa com John Prentice, um médico negro que ela planeja se casar, mas os dois devem enfrentar as preocupações de seus pais e as opiniões da sociedade sobre o casamento inter-racial.",
                                                            "Quando o rico playboy Cary Scott começa a ver o jardineiro viúvo Ron Kirby, ela desafia as convenções sociais locais, mas deve decidir se está pronta para enfrentar o escrutínio e o preconceito para estar com o homem que ela ama.",
                                                            "Uma solitária funcionária (Sandra Bullock) do metrô de Chicago tem fantasias sobre um passageiro habitual (Peter Gallagher) que nunca falou com ela. Um dia ele é assaltado e jogado nos trilhos do metrô. Ela o salva, mas ele fica em coma e quando ela vai visitá-lo no hospital acaba sendo confundida como a noiva da vítima. Se a situação se complica por um lado por outro ela passa a ter novamente uma família para cuidar dela, algo que não sentia há muito tempo, e ao mesmo tempo começa a se apaixonar pelo irmão da vítima (Bill Pullman).",
                                                            "Oliver Barrett IV, um estudante de direito de Harvard, conhece Jenny Cavilleri, uma aluna de música de Radcliffe. É amor à primeira vista, e eles decidem se casar. No entanto, o pai de Oliver, um multimilionário, não aceita tal união e deserda o filho. Jenny não consegue engravidar e descobre que está muito doente.",
                                                            "Durante a Segunda Guerra, um exilado norte-americano encontra refúgio na cidade de Casablanca, no Marrocos, e passa a administrar uma casa noturna. Ele reencontra uma antiga paixão, que agora está casada e precisa de ajuda para fugir dos nazistas.",
                                                            "Na Inglaterra eduardiana, dois homens se mantêm fiéis ao seu amor um pelo outro apesar das pressões para buscar casamentos heterossexuais."
                                                    };
                                                    /*String[] movieImages = {"..\\spec\\movies\\romance\\antigos\\aspontes.jpg", "..\\spec\\movies\\romance\\antigos\\adivinhe.jpg", "..\\spec\\movies\\romance\\antigos\\tardedemais.jpg", "..\\spec\\movies\\romance\\antigos\\enquantovocedormir.jpg", "..\\spec\\movies\\romance\\antigos\\lovestory.jpg", "..\\spec\\movies\\romance\\antigos\\casablanca.jpg", "..\\spec\\movies\\romance\\antigos\\maurice.jpg"};*/

                                                    String[] movieImages = {
                                                                "/movies/romance/antigos/aspontes.jpg",
                                                                "/movies/romance/antigos/adivinhe.jpg",
                                                                "/movies/romance/antigos/tardedemais.jpg",
                                                                "/movies/romance/antigos/enquantovocedormir.jpg",
                                                                "/movies/romance/antigos/lovestory.jpg",
                                                                "/movies/romance/antigos/casablanca.jpg",
                                                                "/movies/romance/antigos/maurice.jpg"
                                                        };

                                                    Random rand = new Random();
                                                    int randomIndex = rand.nextInt(movieList.length);

                                                    JLabel recommendLabel = new JLabel("Recomendamos que você assista:", SwingConstants.CENTER);
                                                    recommendPanel.add(recommendLabel, BorderLayout.NORTH);

                                                    JLabel movieLabel = new JLabel(movieList[randomIndex], SwingConstants.CENTER);
                                                    recommendPanel.add(movieLabel, BorderLayout.WEST);

                                                    JTextArea movieSynopsisArea = new JTextArea(movieSynopsis[randomIndex]);
                                                    movieSynopsisArea.setLineWrap(true);
                                                    movieSynopsisArea.setWrapStyleWord(true);
                                                    movieSynopsisArea.setEditable(false);
                                                    recommendPanel.add(movieSynopsisArea, BorderLayout.CENTER);

                                                    try {
                                                        URL movieImageUrl = getClass().getResource(movieImages[randomIndex]);
                                                        BufferedImage movieImage = ImageIO.read(movieImageUrl);
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    /*
                                                    try {
                                                        BufferedImage movieImage = ImageIO.read(new File(movieImages[randomIndex]));
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    */

                                                    recommendFrame.setLocationRelativeTo(null);
                                                    recommendFrame.setVisible(true);

                                                    romanceOldFrame.dispose();
                                                }
                                            });

                                        } else if (newButton.isSelected()) {
                                            JFrame romanceNewFrame = new JFrame("Gênero Escolhido: Romance - Mais Recentes");
                                            romanceNewFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                            romanceNewFrame.setSize(600, 300);

                                            JPanel romanceNewPanel = new JPanel(new BorderLayout());
                                            romanceNewFrame.add(romanceNewPanel);

                                            JLabel questionLabel = new JLabel("Voce prefere filmes de romance mais recentes bem avaliados(IMDb alto) ?", SwingConstants.CENTER); //caso nao selecionado as opções, sera considerado o valor "Sim"
                                            romanceNewPanel.add(questionLabel, BorderLayout.NORTH);

                                            ButtonGroup romanceNewGroup = new ButtonGroup();
                                            JRadioButton yesButton = new JRadioButton("Sim");
                                            JRadioButton dontMindButton = new JRadioButton("Não me importo");
                                            romanceNewGroup.add(yesButton);
                                            romanceNewGroup.add(dontMindButton);

                                            JPanel radioPanel = new JPanel();
                                            radioPanel.add(yesButton);
                                            radioPanel.add(dontMindButton);

                                            romanceNewPanel.add(radioPanel, BorderLayout.CENTER);

                                            JButton sendButton = new JButton("Enviar");
                                            romanceNewPanel.add(sendButton, BorderLayout.SOUTH);

                                            sendButton.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    JFrame recommendFrame = new JFrame("Recomendação de Filme");
                                                    recommendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                    recommendFrame.setSize(700, 400);

                                                    JPanel recommendPanel = new JPanel(new BorderLayout());
                                                    recommendFrame.add(recommendPanel);

                                                    String[] movieList = {"A Culpa é das Estrelas", "Me Chame pelo Seu Nome", "La La Land", "História de um Casamento", "The Big Sick", "Antes do Amanhecer", "500 Dias com Ela"};
                                                    String[] movieSynopsis = {
                                                            "Hazel Grace Lancaster e Augustus Waters são dois adolescentes que se conhecem em um grupo de apoio para pacientes com câncer. Por causa da doença, Hazel sempre descartou a ideia de se envolver amorosamente, mas acaba cedendo ao se apaixonar por Augustus. Juntos, eles viajam para Amsterdã, onde embarcam em uma jornada inesquecível.",
                                                            "O jovem Elio está enfrentando outro verão preguiçoso na casa de seus pais na bela e lânguida paisagem italiana. Mas tudo muda com a chegada de Oliver, um acadêmico que veio ajudar a pesquisa de seu pai.",
                                                            "O pianista Sebastian conhece a atriz Mia, e os dois se apaixonam perdidamente. Em busca de oportunidades para suas carreiras na competitiva Los Angeles, os jovens tentam fazer o relacionamento amoroso dar certo, enquanto perseguem fama e sucesso.",
                                                            "Após anos juntos, Nicole e Charlie veem seu casamento ruir. Charlie é um diretor de sucesso e Nicole uma atriz que deixou sua carreira de lado. Em meio a discussões e ressentimento, os dois tentam salvar o que resta de sua relação.",
                                                            "O comediante paquistanês Kumail e a estudante de graduação Emily se apaixonam, mas encontram dificuldades quando suas culturas entram em conflito.",
                                                            "Jesse, um jovem americano, e Celine, uma linda francesa, se conhecem no trem para Paris, e começam uma conversa que os leva a fazer uma escala em Viena e ficar um pouco mais juntos, sem imaginar o que o destino os reserva.",
                                                            "Um romântico escritor se surpreende quando sua namorada Summer termina o namoro repentinamente. Com isso, ele relembra vários momentos dos 500 dias que passaram juntos para tentar descobrir onde seu caso de amor se perdeu e vai redescobrindo suas verdadeiras paixões."
                                                    };
                                                    /*String[] movieImages = {"..\\spec\\movies\\romance\\recentes\\aculpa.jpg", "..\\spec\\movies\\romance\\recentes\\mechame.jpg", "..\\spec\\movies\\romance\\recentes\\lalaland.jpg", "..\\spec\\movies\\romance\\recentes\\historia.jpg", "..\\spec\\movies\\romance\\recentes\\thebig.jpg", "..\\spec\\movies\\romance\\recentes\\antesdo.jpg", "..\\spec\\movies\\romance\\recentes\\500dias.jpg"};*/
                                                    String[] movieImages = {
                                                                "/movies/romance/recentes/aculpa.jpg",
                                                                "/movies/romance/recentes/mechame.jpg",
                                                                "/movies/romance/recentes/lalaland.jpg",
                                                                "/movies/romance/recentes/historia.jpg",
                                                                "/movies/romance/recentes/thebig.jpg",
                                                                "/movies/romance/recentes/antesdo.jpg",
                                                                "/movies/romance/recentes/500dias.jpg"
                                                        };

                                                    Random rand = new Random();
                                                    int randomIndex = rand.nextInt(movieList.length);

                                                    JLabel recommendLabel = new JLabel("Recomendamos que assista:", SwingConstants.CENTER);
                                                    recommendPanel.add(recommendLabel, BorderLayout.NORTH);

                                                    JLabel movieLabel = new JLabel(movieList[randomIndex], SwingConstants.CENTER);
                                                    recommendPanel.add(movieLabel, BorderLayout.WEST);

                                                    JTextArea movieSynopsisArea = new JTextArea(movieSynopsis[randomIndex]);
                                                    movieSynopsisArea.setLineWrap(true);
                                                    movieSynopsisArea.setWrapStyleWord(true);
                                                    movieSynopsisArea.setEditable(false);
                                                    recommendPanel.add(movieSynopsisArea, BorderLayout.CENTER);

                                                    try {
                                                        URL movieImageUrl = getClass().getResource(movieImages[randomIndex]);
                                                        BufferedImage movieImage = ImageIO.read(movieImageUrl);
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    /*
                                                    try {
                                                        BufferedImage movieImage = ImageIO.read(new File(movieImages[randomIndex]));
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    */

                                                    recommendFrame.setLocationRelativeTo(null);
                                                    recommendFrame.setVisible(true);

                                                    romanceNewFrame.dispose();
                                                }
                                            });

                                            romanceNewFrame.setLocationRelativeTo(null);
                                            romanceNewFrame.setVisible(true);

                                            romanceFrame.dispose();
                                        }
                                    }
                                });
                            } else if (selectedGenre.equals("Documentário")) {
                                JFrame documentaryFrame = new JFrame("Gênero Escolhido: Documentário");
                                documentaryFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                documentaryFrame.setSize(600, 300);

                                JPanel documentaryPanel = new JPanel(new BorderLayout());
                                documentaryFrame.add(documentaryPanel);

                                JLabel questionLabel = new JLabel("Você prefere documentários mais antigos ? ou mais recentes ?", SwingConstants.CENTER);
                                documentaryPanel.add(questionLabel, BorderLayout.NORTH);

                                ButtonGroup documentaryGroup = new ButtonGroup();
                                JRadioButton oldButton = new JRadioButton("Mais antigos");
                                JRadioButton newButton = new JRadioButton("Mais recentes");
                                documentaryGroup.add(oldButton);
                                documentaryGroup.add(newButton);

                                JPanel radioPanel = new JPanel();
                                radioPanel.add(oldButton);
                                radioPanel.add(newButton);

                                documentaryPanel.add(radioPanel, BorderLayout.CENTER);

                                JButton sendButton = new JButton("Enviar");
                                documentaryPanel.add(sendButton, BorderLayout.SOUTH);

                                documentaryFrame.setLocationRelativeTo(null);
                                documentaryFrame.setVisible(true);

                                genreFrame.dispose();

                                sendButton.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        if (oldButton.isSelected()) {

                                            JFrame documentaryOldFrame = new JFrame("Gênero Escolhido: Documentário - Mais Antigo");
                                            documentaryOldFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                            documentaryOldFrame.setSize(600, 300);

                                            JPanel documentaryOldPanel = new JPanel(new BorderLayout());
                                            documentaryOldFrame.add(documentaryOldPanel);

                                            JLabel questionLabel = new JLabel("Você prefere documentários mais antigos bem avaliados (IMDb alto)?", SwingConstants.CENTER); //caso nao selecionado as opções, sera considerado o valor "Sim"
                                            documentaryOldPanel.add(questionLabel, BorderLayout.NORTH);

                                            ButtonGroup documentaryOldGroup = new ButtonGroup();
                                            JRadioButton yesButton = new JRadioButton("Sim");
                                            JRadioButton dontMindButton = new JRadioButton("Não me importo");
                                            documentaryOldGroup.add(yesButton);
                                            documentaryOldGroup.add(dontMindButton);

                                            JPanel radioPanel = new JPanel();
                                            radioPanel.add(yesButton);
                                            radioPanel.add(dontMindButton);

                                            documentaryOldPanel.add(radioPanel, BorderLayout.CENTER);

                                            JButton sendButton = new JButton("Enviar");
                                            documentaryOldPanel.add(sendButton, BorderLayout.SOUTH);

                                            documentaryOldFrame.setLocationRelativeTo(null);
                                            documentaryOldFrame.setVisible(true);

                                            documentaryFrame.dispose();

                                            sendButton.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    JFrame recommendFrame = new JFrame("Recomendação de Documentário");
                                                    recommendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                    recommendFrame.setSize(700, 400);

                                                    JPanel recommendPanel = new JPanel(new BorderLayout());
                                                    recommendFrame.add(recommendPanel);

                                                    String[] documentaryList = {"Fantasmas do Abismo", "Grey Gardens", "Ghost Adventures", "Planeta Terra", "Mayday! Desastres Aéreos", "O Mundo em Guerra", "O Homem dos Músculos de Aço"};
                                                    String[] documentarySynopsis = {
                                                            "James Cameron investiga os escombros do Titanic por completo junto a uma equipe de cientistas, cineastas e historiadores.",
                                                            "Um documentário que explora a vida de Edith Bouvier Beale e sua filha Edith, tia e prima de Jacqueline Kennedy Onassis, respectivamente. As duas vivem juntas em uma mansão decadente em East Hampton.",
                                                            "O investigador paranormal Zak Bagans lidera sua equipe de co-investigadores Nick Groff e Aaron Goodwin em locais assombrados na América e no exterior, entrevistando moradores sobre supostas assombrações antes de encarar as entidades sobrenaturais.",
                                                            "Das tundras geladas às florestas equatoriais, David Attenborough apresenta um grande panorama visual do planeta. Os episódios oferecem imagens impressionantes de montanhas, planícies, florestas, cavernas e outros tipos de topografia.",
                                                            "Acidentes catastróficos da história da aviação são meticulosamente encenados, fornecendo informações sobre o que deu errado e se os acidentes poderiam ter sido evitados.",
                                                            "The World at War é uma série de documentários britânica que relata os eventos da Segunda Guerra Mundial.",
                                                            "O documentário independente evidenciou o mundo do fisiculturismo, lançou a carreira multimilionária de um homem e mudou o mundo da musculação e exercício físico para sempre. Acompanhe o cinco vezes Mr. Olympia, Arnold Schwarzenegger, enquanto ele compete pelo seu sexto título."
                                                    };
                                                    /*String[] documentaryImages = {"..\\spec\\movies\\documentarios\\antigos\\fantasmas.jpg", "..\\spec\\movies\\documentarios\\antigos\\greygardens.jpg", "..\\spec\\movies\\documentarios\\antigos\\ghostadventures.jpg", "..\\spec\\movies\\documentarios\\antigos\\planeta.jpg", "..\\spec\\movies\\documentarios\\antigos\\mayday.jpg", "..\\spec\\movies\\documentarios\\antigos\\mundoemguerra.jpg", "..\\spec\\movies\\documentarios\\antigos\\homemdosmusculos.jpg"};*/
                                                    String[] movieImages = {
                                                                "/movies/documentarios/antigos/fantasmas.jpg",
                                                                "/movies/documentarios/antigos/greygardens.jpg",
                                                                "/movies/documentarios/antigos/ghostadventures.jpg",
                                                                "/movies/documentarios/antigos/planeta.jpg",
                                                                "/movies/documentarios/antigos/mayday.jpg",
                                                                "/movies/documentarios/antigos/mundoemguerra.jpg",
                                                                "/movies/documentarios/antigos/homemdosmusculos.jpg"
                                                        };

                                                    Random rand = new Random();
                                                    int randomIndex = rand.nextInt(documentaryList.length);

                                                    JLabel recommendLabel = new JLabel("Recomendamos para você assistir o seguinte documentário:", SwingConstants.CENTER);
                                                    recommendPanel.add(recommendLabel, BorderLayout.NORTH);

                                                    JLabel documentaryLabel = new JLabel(documentaryList[randomIndex], SwingConstants.CENTER);
                                                    recommendPanel.add(documentaryLabel, BorderLayout.WEST);

                                                    JTextArea documentarySynopsisArea = new JTextArea(documentarySynopsis[randomIndex]);
                                                    documentarySynopsisArea.setLineWrap(true);
                                                    documentarySynopsisArea.setWrapStyleWord(true);
                                                    documentarySynopsisArea.setEditable(false);
                                                    recommendPanel.add(documentarySynopsisArea, BorderLayout.CENTER);

                                                    try {
                                                        URL movieImageUrl = getClass().getResource(movieImages[randomIndex]);
                                                        BufferedImage movieImage = ImageIO.read(movieImageUrl);
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    /*
                                                    try {
                                                        BufferedImage documentaryImage = ImageIO.read(new File(documentaryImages[randomIndex]));
                                                        JLabel picLabel = new JLabel(new ImageIcon(documentaryImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    */

                                                    recommendFrame.setLocationRelativeTo(null);
                                                    recommendFrame.setVisible(true);

                                                    documentaryOldFrame.dispose();
                                                }
                                            });
                                        } else if (newButton.isSelected()) {
                                            JFrame documentaryRecentFrame = new JFrame("Gênero Escolhido: Documentário - Mais Recentes");
                                            documentaryRecentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                            documentaryRecentFrame.setSize(600, 300);

                                            JPanel documentaryRecentPanel = new JPanel(new BorderLayout());
                                            documentaryRecentFrame.add(documentaryRecentPanel);

                                            JLabel questionLabel = new JLabel("Você prefere documentários mais recentes bem avaliados (IMDb alto)?", SwingConstants.CENTER); //caso nao selecionado as opções, sera considerado o valor "Sim"
                                            documentaryRecentPanel.add(questionLabel, BorderLayout.NORTH);

                                            ButtonGroup documentaryRecentGroup = new ButtonGroup();
                                            JRadioButton yesButton = new JRadioButton("Sim");
                                            JRadioButton dontMindButton = new JRadioButton("Não me importo");
                                            documentaryRecentGroup.add(yesButton);
                                            documentaryRecentGroup.add(dontMindButton);

                                            JPanel radioPanel = new JPanel();
                                            radioPanel.add(yesButton);
                                            radioPanel.add(dontMindButton);

                                            documentaryRecentPanel.add(radioPanel, BorderLayout.CENTER);

                                            JButton sendButton = new JButton("Enviar");
                                            documentaryRecentPanel.add(sendButton, BorderLayout.SOUTH);

                                            documentaryRecentFrame.setLocationRelativeTo(null);
                                            documentaryRecentFrame.setVisible(true);

                                            documentaryFrame.dispose();

                                            sendButton.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    if (yesButton.isSelected() || dontMindButton.isSelected()) {
                                                        JFrame recommendFrame = new JFrame("Recomendação de Documentário");
                                                        recommendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                        recommendFrame.setSize(700, 400);

                                                        JPanel recommendPanel = new JPanel(new BorderLayout());
                                                        recommendFrame.add(recommendPanel);

                                                        String[] documentaryList = {"All the Beauty and the Bloodshed", "The Rescue", "Assassinato nas Profundezas", "Vítima X Suspeita", "O Mistério de Maya", "Arnold", "Nosso Planeta", "Stan Lee", "Tour de France: No Coração do Pelotão"};
                                                        String[] documentarySynopsis = {
                                                                "All the Beauty and the Bloodshed é um longa-metragem documental estadunidense, lançado em 2022, que aborda a carreira da artista Nan Goldin e a queda do império farmacêutico da família Sackler.",
                                                                "Os membros de uma equipe de resgate tentam salvar 12 meninos e um técnico presos dentro de uma caverna alagada na Tailândia.",
                                                                "A jornalista Kim Wall embarca no submarino do empresário Peter Madsen, um homem brilhante e adorado por todos, para fazer uma reportagem. Mas a mulher morre misteriosamente, e as suspeitas recaem sobre Madsen, revelando uma história aterrorizante.",
                                                                "Uma jornalista decide investigar o caso de uma mulher acusada de denunciar um falso estupro, mas acaba descobrindo um padrão preocupante nos procedimentos da polícia.",
                                                                "Casal acusado de abuso infantil enfrenta as autoridades da Flórida para recuperar a guarda da filha.",
                                                                "Esta série documental intimista retrata a vida e a carreira multifacetada de Arnold Schwarzenegger, campeão de fisiculturismo, astro de Hollywood e político.",
                                                                "Com imagens nunca vistas, esse ambicioso documentário mostra a beleza natural da Terra e mostra como as mudanças climáticas têm impacto sobre todas as criaturas vivas.",
                                                                "Retrata a jornada de Stan Lee, revelando como ele se tornou uma figura de imensa influência na cultura popular. O filme abrange desde sua infância e juventude como Stanley Lieber, seu nome de nascimento, até seu rápido e notável sucesso na Marvel.",
                                                                "Em meio a lágrimas e conquistas, essa série acompanha diversas equipes na edição de 2022 da competição de ciclismo mais desafiadora do mundo.."
                                                        };
                                                        /*String[] documentaryImages = {"..\\spec\\movies\\documentarios\\recentes\\allthebeauty.jpg", "..\\spec\\movies\\documentarios\\recentes\\therescue.jpg", "..\\spec\\movies\\documentarios\\recentes\\assassinatonasprofundezas.jpg", "..\\spec\\movies\\documentarios\\recentes\\vitimasuspeita.jpg", "..\\spec\\movies\\documentarios\\recentes\\omisteriomaya.jpg", "..\\spec\\movies\\documentarios\\recentes\\arnold.jpg", "..\\spec\\movies\\documentarios\\recentes\\nossoplaneta.jpg", "..\\spec\\movies\\documentarios\\recentes\\stanlee.jpg", "..\\spec\\movies\\documentarios\\recentes\\tourdefrance.jpg"};*/

                                                        String[] movieImages = {
                                                                "/movies/documentarios/recentes/allthebeauty.jpg",
                                                                "/movies/documentarios/recentes/therescue.jpg",
                                                                "/movies/documentarios/recentes/assassinatonasprofundezas.jpg",
                                                                "/movies/documentarios/recentes/vitimasuspeita.jpg",
                                                                "/movies/documentarios/recentes/omisteriomaya.jpg",
                                                                "/movies/documentarios/recentes/arnold.jpg",
                                                                "/movies/documentarios/recentes/nossoplaneta.jpg",
                                                                "/movies/documentarios/recentes/stanlee.jpg",
                                                                "/movies/documentarios/recentes/tourdefrance.jpg"
                                                        };

                                                        Random rand = new Random();
                                                        int randomIndex = rand.nextInt(documentaryList.length);

                                                        JLabel recommendLabel = new JLabel("Recomendamos para você assistir o seguinte documentário:", SwingConstants.CENTER);
                                                        recommendPanel.add(recommendLabel, BorderLayout.NORTH);

                                                        JLabel documentaryLabel = new JLabel(documentaryList[randomIndex], SwingConstants.CENTER);
                                                        recommendPanel.add(documentaryLabel, BorderLayout.WEST);

                                                        JTextArea documentarySynopsisArea = new JTextArea(documentarySynopsis[randomIndex]);
                                                        documentarySynopsisArea.setLineWrap(true);
                                                        documentarySynopsisArea.setWrapStyleWord(true);
                                                        documentarySynopsisArea.setEditable(false);
                                                        recommendPanel.add(documentarySynopsisArea, BorderLayout.CENTER);

                                                        try {
                                                            URL movieImageUrl = getClass().getResource(movieImages[randomIndex]);
                                                            BufferedImage movieImage = ImageIO.read(movieImageUrl);
                                                            JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                            recommendPanel.add(picLabel, BorderLayout.EAST);
                                                        } catch (IOException ex) {
                                                            ex.printStackTrace();
                                                        }
                                                        /*
                                                        try {
                                                            BufferedImage documentaryImage = ImageIO.read(new File(documentaryImages[randomIndex]));
                                                            JLabel picLabel = new JLabel(new ImageIcon(documentaryImage));
                                                            recommendPanel.add(picLabel, BorderLayout.EAST);
                                                        } catch (IOException ex) {
                                                            ex.printStackTrace();
                                                        }
                                                        */

                                                        recommendFrame.setLocationRelativeTo(null);
                                                        recommendFrame.setVisible(true);

                                                        documentaryRecentFrame.dispose();
                                                    }
                                                }
                                            });
                                        }
                                    }
                                });
                            } else if (selectedGenre.equals("Suspense")) {
                                JFrame suspenseFrame = new JFrame("Gênero Escolhido: Suspense");
                                suspenseFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                suspenseFrame.setSize(600, 300);

                                JPanel suspensePanel = new JPanel(new BorderLayout());
                                suspenseFrame.add(suspensePanel);

                                JLabel questionLabel = new JLabel("Você prefere filmes de suspense mais antigos ? ou mais recentes ?", SwingConstants.CENTER);
                                suspensePanel.add(questionLabel, BorderLayout.NORTH);

                                ButtonGroup suspenseGroup = new ButtonGroup();
                                JRadioButton oldButton = new JRadioButton("Mais antigo");
                                JRadioButton newButton = new JRadioButton("Mais recente");
                                suspenseGroup.add(oldButton);
                                suspenseGroup.add(newButton);

                                JPanel radioPanel = new JPanel();
                                radioPanel.add(oldButton);
                                radioPanel.add(newButton);

                                suspensePanel.add(radioPanel, BorderLayout.CENTER);

                                JButton sendButton = new JButton("Enviar");
                                suspensePanel.add(sendButton, BorderLayout.SOUTH);

                                suspenseFrame.setLocationRelativeTo(null);
                                suspenseFrame.setVisible(true);

                                genreFrame.dispose();

                                sendButton.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        if (oldButton.isSelected()) {

                                            if (oldButton.isSelected()) {
                                                JFrame oldSuspenseFrame = new JFrame("Escolha de Suspense: Mais antigo");
                                                oldSuspenseFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                oldSuspenseFrame.setSize(600, 300);

                                                JPanel oldSuspensePanel = new JPanel(new BorderLayout());
                                                oldSuspenseFrame.add(oldSuspensePanel);

                                                JLabel questionLabel = new JLabel("Você prefere filmes de suspense mais antigos bem avaliados (IMDb alto)?", SwingConstants.CENTER); //caso nao selecionado as opções, sera considerado o valor "Sim"
                                                oldSuspensePanel.add(questionLabel, BorderLayout.NORTH);

                                                ButtonGroup oldSuspenseGroup = new ButtonGroup();
                                                JRadioButton yesButton = new JRadioButton("Sim");
                                                JRadioButton dontMindButton = new JRadioButton("Não me importo");
                                                oldSuspenseGroup.add(yesButton);
                                                oldSuspenseGroup.add(dontMindButton);

                                                JPanel radioPanel = new JPanel();
                                                radioPanel.add(yesButton);
                                                radioPanel.add(dontMindButton);

                                                oldSuspensePanel.add(radioPanel, BorderLayout.CENTER);

                                                JButton sendButton = new JButton("Enviar");
                                                oldSuspensePanel.add(sendButton, BorderLayout.SOUTH);

                                                oldSuspenseFrame.setLocationRelativeTo(null);
                                                oldSuspenseFrame.setVisible(true);

                                                suspenseFrame.dispose();

                                                sendButton.addActionListener(new ActionListener() {
                                                    @Override
                                                    public void actionPerformed(ActionEvent e) {
                                                        JFrame recommendFrame = new JFrame("Recomendação de Suspense Antigo");
                                                        recommendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                        recommendFrame.setSize(700, 400);

                                                        JPanel recommendPanel = new JPanel(new BorderLayout());
                                                        recommendFrame.add(recommendPanel);

                                                        String[] suspenseList = {"Psicose", "Janela Indiscreta", "Os Pássaros", "O Terceiro Homem", "Laura", "Gravidade", "Vida", "Cemitério Maldito"};
                                                        String[] suspenseSynopsis = {
                                                                "Após roubar 40 mil dólares para se casar com o namorado, uma mulher foge durante uma tempestade e decide passar a noite em um hotel que encontra pelo caminho. Ela conhece o educado e nervoso proprietário do estabelecimento, Norman Bates, um jovem com um interesse em taxidermia e com uma relação conturbada com sua mãe. O que parece ser uma simples estadia no local se torna uma verdadeira noite de terror.",
                                                                "Em Greenwich Village, Nova York, L.B. Jeffries, um fotógrafo profissional, está confinado em seu apartamento por ter quebrado a perna enquanto trabalhava. Como não tem muitas opções de lazer, vasculha a vida dos seus vizinhos com um binóculo, quando vê alguns acontecimentos que o fazem suspeitar que um assassinato foi cometido.",
                                                                "Melanie Daniels, uma bela e rica socialite, conhece o advogado Mitch Brenner em um pet shop e fica interessada nele. Após o encontro, ela decide procurá-lo na cidade de Bodega Bay, Califórnia, onde Mitch costuma passar os finais de semana. Entretanto, Melaine só não sabia que iria vivenciar algo assustador: milhares de pássaros se instalaram na localidade e começam a atacar as pessoas.",
                                                                "Um escritor americano chega a Viena, após a Segunda Guerra, e descobre que seu amigo Harry Lime foi morto sob circunstâncias misteriosas. Ele passa a investigar o caso e descobre várias inconsistências nas explicações dos amigos de Harry.",
                                                                "Em um dos mais famosos film noir dos anos 40, o detetive de Manhattan Mark McPherson (Dana Andrews) investiga o assassinato de uma executiva da Madison Avenue, Laura Hunt (Gene Tierney), em seu sofisticado apartamento. No decorrer da investigacao, McPherson interroga o arrogante melhor amigo de Laura, o colunista de fofocas Waldo Lydecker (Clifton Webb),e seu noivo, Shelby Carpenter (Vincent Price). Obcecado com o caso, o detetive descobre que está apaixonado pela mulher morta.",
                                                                "Dra. Ryan Stone e o astronauta Matt Kowalsky trabalham juntos para sobreviver depois que um acidente os deixa completamente à deriva no espaço, sem ligação com a Terra e sem esperança de resgate.",
                                                                "Uma equipe de seis astronautas da Estação Espacial Internacional descobre sinais de vida inteligente em Marte e a investigação do fato gera consequências inimagináveis.",
                                                                "Uma família se muda para uma nova casa, localizada nos arredores de um antigo cemitério amaldiçoado, usado para enterrar animais de estimação, mas que já foi usado para sepultamento de indígenas. Algumas coisas estranhas começam a acontecer, transformando a vida cotidiana dos moradores em um pesadelo."
                                                        };
                                                        /*String[] suspenseImages = {"..\\spec\\movies\\suspense\\antigos\\psicose.jpg", "..\\spec\\movies\\suspense\\antigos\\janelaindiscreta.jpg", "..\\spec\\movies\\suspense\\antigos\\ospassaros.jpg", "..\\spec\\movies\\suspense\\antigos\\oterceirohomem.jpg", "..\\spec\\movies\\suspense\\antigos\\laura.jpg", "..\\spec\\movies\\suspense\\antigos\\gravidade.jpg", "..\\spec\\movies\\suspense\\antigos\\vida.jpg", "..\\spec\\movies\\suspense\\antigos\\cemiteriomaldito.jpg"};*/

                                                        String[] movieImages = {
                                                                "/movies/suspense/antigos/psicose.jpg",
                                                                "/movies/suspense/antigos/janelaindiscreta.jpg",
                                                                "/movies/suspense/antigos/ospassaros.jpg",
                                                                "/movies/suspense/antigos/oterceirohomem.jpg",
                                                                "/movies/suspense/antigos/laura.jpg",
                                                                "/movies/suspense/antigos/gravidade.jpg",
                                                                "/movies/suspense/antigos/vida.jpg",
                                                                "/movies/suspense/antigos/cemiteriomaldito.jpg"
                                                        };

                                                        Random rand = new Random();
                                                        int randomIndex = rand.nextInt(suspenseList.length);

                                                        JLabel recommendLabel = new JLabel("Recomendamos para você assistir o seguinte suspense:", SwingConstants.CENTER);
                                                        recommendPanel.add(recommendLabel, BorderLayout.NORTH);

                                                        JLabel suspenseLabel = new JLabel(suspenseList[randomIndex], SwingConstants.CENTER);
                                                        recommendPanel.add(suspenseLabel, BorderLayout.WEST);

                                                        JTextArea suspenseSynopsisArea = new JTextArea(suspenseSynopsis[randomIndex]);
                                                        suspenseSynopsisArea.setLineWrap(true);
                                                        suspenseSynopsisArea.setWrapStyleWord(true);
                                                        suspenseSynopsisArea.setEditable(false);
                                                        recommendPanel.add(suspenseSynopsisArea, BorderLayout.CENTER);

                                                        try {
                                                            URL movieImageUrl = getClass().getResource(movieImages[randomIndex]);
                                                            BufferedImage movieImage = ImageIO.read(movieImageUrl);
                                                            JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                            recommendPanel.add(picLabel, BorderLayout.EAST);
                                                        } catch (IOException ex) {
                                                            ex.printStackTrace();
                                                        }
                                                        /*
                                                        try {
                                                            BufferedImage suspenseImage = ImageIO.read(new File(suspenseImages[randomIndex]));
                                                            JLabel picLabel = new JLabel(new ImageIcon(suspenseImage));
                                                            recommendPanel.add(picLabel, BorderLayout.EAST);
                                                        } catch (IOException ex) {
                                                            ex.printStackTrace();
                                                        }
                                                        */

                                                        recommendFrame.setLocationRelativeTo(null);
                                                        recommendFrame.setVisible(true);

                                                        oldSuspenseFrame.dispose();
                                                    }
                                                });
                                            }
                                        } else if (newButton.isSelected()) {
                                            JFrame newSuspenseFrame = new JFrame("Gênero Escolhido: Suspense - Mais Recente");
                                            newSuspenseFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                            newSuspenseFrame.setSize(600, 300);

                                            JPanel newSuspensePanel = new JPanel(new BorderLayout());
                                            newSuspenseFrame.add(newSuspensePanel);

                                            JLabel questionLabel = new JLabel("Você prefere filmes de suspense mais recentes bem avaliados (IMDb alto)?", SwingConstants.CENTER); //caso nao selecionado as opções, sera considerado o valor "Sim"
                                            newSuspensePanel.add(questionLabel, BorderLayout.NORTH);

                                            ButtonGroup newSuspenseGroup = new ButtonGroup();
                                            JRadioButton yesButton = new JRadioButton("Sim");
                                            JRadioButton dontMindButton = new JRadioButton("Não me importo");
                                            newSuspenseGroup.add(yesButton);
                                            newSuspenseGroup.add(dontMindButton);

                                            JPanel radioPanel = new JPanel();
                                            radioPanel.add(yesButton);
                                            radioPanel.add(dontMindButton);

                                            newSuspensePanel.add(radioPanel, BorderLayout.CENTER);

                                            JButton sendButton = new JButton("Enviar");
                                            newSuspensePanel.add(sendButton, BorderLayout.SOUTH);

                                            newSuspenseFrame.setLocationRelativeTo(null);
                                            newSuspenseFrame.setVisible(true);

                                            suspenseFrame.dispose();

                                            sendButton.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    if (yesButton.isSelected() || dontMindButton.isSelected()) {
                                                        JFrame recommendFrame = new JFrame("Recomendação de Suspense Recente");
                                                        recommendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                        recommendFrame.setSize(700, 400);

                                                        JPanel recommendPanel = new JPanel(new BorderLayout());
                                                        recommendFrame.add(recommendPanel);

                                                        String[] recentSuspenseList = {"Parasita", "Entre Facas e Segredos", "O Homem Invisível", "007: Sem Tempo para Morrer", "Invocação do Mal 3: A Ordem do Demônio", "Nem um Passo em Falso", "Os Pequenos Vestígios", "Um Lugar Bem Longe Daqui"};
                                                        String[] recentSuspenseSynopsis = {
                                                                "Toda a família de Ki-taek está desempregada, vivendo em um porão sujo e apertado. Por obra do acaso, ele começa a dar aulas de inglês para uma garota de família rica. Fascinados com a vida luxuosa destas pessoas, pai, mãe e filhos bolam um plano para se infiltrar também na abastada família, um a um. No entanto, os segredos e mentiras necessários à ascensão social cobram o seu preço.",
                                                                "Depois de fazer 85 anos, Harlan Thrombey, um famoso escritor de histórias policiais, é encontrado morto. Contratado para investigar o caso, o detetive Benoit Blanc descobre que, entre os funcionários misteriosos e a família conflituosa de Harlan, todos podem ser considerados suspeitos do crime.",
                                                                "Depois de forjar o próprio suicídio, um cientista enlouquecido usa seu poder para se tornar invisível e aterrorizar sua ex-namorada. Quando a polícia se recusa a acreditar em sua história, ela decide resolver o assunto por conta própria.",
                                                                "James Bond deixa o MI6 e se muda para a Jamaica, mas um antigo amigo aparece e pede sua ajuda para encontrar um cientista desaparecido. Bond mergulha no caso e percebe que a busca é, na verdade, uma corrida para salvar o mundo.",
                                                                "Os investigadores paranormais Ed e Lorraine Warren assumem um dos casos mais sensacionais de suas carreiras quando um jovem suspeito de assassinato alega posse demoníaca como defesa.",
                                                                "Em Detroit, em 1954, criminosos são contratados para roubar um documento. Quando o assalto dá terrivelmente errado, eles passam a buscar por quem os contratou e com que propósito..",
                                                                "O delegado adjunto do condado de Kern, Joe Deke Deacon, é enviado a Los Angeles para o que deveria ser uma rápida coleta de provas. Em vez disso, ele se envolve na busca por um assassino em série que está aterrorizando a cidade. À frente do caso, Jim Baxter, delegado do Departamento de Polícia de Los Angeles, impressionado com os instintos de Deke, designa o policial, extraoficialmente, para ajudá-lo.",
                                                                "Abandonada quando menina, Kya cresceu nos perigosos pântanos da Carolina do Norte. Quando um garoto da cidade é encontrado morto, Kya imediatamente se torna a principal suspeita. À medida que o caso se desenrola, o veredicto torna-se mais obscuro."
                                                        };
                                                        /*String[] recentSuspenseImages = {"..\\spec\\movies\\suspense\\recentes\\parasita.jpg", "..\\spec\\movies\\suspense\\recentes\\entrefacasesegredos.jpg", "..\\spec\\movies\\suspense\\recentes\\ohomeminvisivel.jpg", "..\\spec\\movies\\suspense\\recentes\\007semtempoparamorrer.jpg", "..\\spec\\movies\\suspense\\recentes\\invocacaodomal3.jpg", "..\\spec\\movies\\suspense\\recentes\\nemumpassoemfalso.jpg", "..\\spec\\movies\\suspense\\recentes\\ospequenosvestigios.jpg", "..\\spec\\movies\\suspense\\recentes\\umlugarbemlongedaqui.jpg"};*/
                                                        String[] movieImages = {
                                                                "/movies/suspense/recentes/parasita.jpg",
                                                                "/movies/suspense/recentes/entrefacasesegredos.jpg",
                                                                "/movies/suspense/recentes/ohomeminvisivel.jpg",
                                                                "/movies/suspense/recentes/007semtempoparamorrer.jpg",
                                                                "/movies/suspense/recentes/invocacaodomal3.jpg",
                                                                "/movies/suspense/recentes/nemumpassoemfalso.jpg",
                                                                "/movies/suspense/recentes/ospequenosvestigios.jpg",
                                                                "/movies/suspense/recentes/umlugarbemlongedaqui.jpg",
                                                        };

                                                        Random rand = new Random();
                                                        int randomIndex = rand.nextInt(recentSuspenseList.length);

                                                        JLabel recommendLabel = new JLabel("Sugiro que você dê uma chance a este filme:", SwingConstants.CENTER);
                                                        recommendPanel.add(recommendLabel, BorderLayout.NORTH);

                                                        JLabel suspenseLabel = new JLabel(recentSuspenseList[randomIndex], SwingConstants.CENTER);
                                                        recommendPanel.add(suspenseLabel, BorderLayout.WEST);

                                                        JTextArea suspenseSynopsisArea = new JTextArea(recentSuspenseSynopsis[randomIndex]);
                                                        suspenseSynopsisArea.setLineWrap(true);
                                                        suspenseSynopsisArea.setWrapStyleWord(true);
                                                        suspenseSynopsisArea.setEditable(false);
                                                        recommendPanel.add(suspenseSynopsisArea, BorderLayout.CENTER);

                                                        try {
                                                            URL movieImageUrl = getClass().getResource(movieImages[randomIndex]);
                                                            BufferedImage movieImage = ImageIO.read(movieImageUrl);
                                                            JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                            recommendPanel.add(picLabel, BorderLayout.EAST);
                                                        } catch (IOException ex) {
                                                            ex.printStackTrace();
                                                        }
                                                        /*
                                                        try {
                                                            BufferedImage suspenseImage = ImageIO.read(new File(recentSuspenseImages[randomIndex]));
                                                            JLabel picLabel = new JLabel(new ImageIcon(suspenseImage));
                                                            recommendPanel.add(picLabel, BorderLayout.EAST);
                                                        } catch (IOException ex) {
                                                            ex.printStackTrace();
                                                        }
                                                        */

                                                        recommendFrame.setLocationRelativeTo(null);
                                                        recommendFrame.setVisible(true);

                                                        newSuspenseFrame.dispose();
                                                    }
                                                }
                                            });
                                        }
                                    }
                                });
                            } else if (selectedGenre.equals("Terror")) {
                                JFrame terrorFrame = new JFrame("Gênero Escolhido: Terror");
                                terrorFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                terrorFrame.setSize(600, 300);

                                JPanel terrorPanel = new JPanel(new BorderLayout());
                                terrorFrame.add(terrorPanel);

                                JLabel questionLabel = new JLabel("Você prefere filmes de terror mais antigos ? ou mais recentes ?", SwingConstants.CENTER);
                                terrorPanel.add(questionLabel, BorderLayout.NORTH);

                                ButtonGroup terrorGroup = new ButtonGroup();
                                JRadioButton oldButton = new JRadioButton("Mais antigo");
                                JRadioButton newButton = new JRadioButton("Mais recente");
                                terrorGroup.add(oldButton);
                                terrorGroup.add(newButton);

                                JPanel radioPanel = new JPanel();
                                radioPanel.add(oldButton);
                                radioPanel.add(newButton);

                                terrorPanel.add(radioPanel, BorderLayout.CENTER);

                                JButton sendButton = new JButton("Enviar");
                                terrorPanel.add(sendButton, BorderLayout.SOUTH);

                                terrorFrame.setLocationRelativeTo(null);
                                terrorFrame.setVisible(true);

                                genreFrame.dispose();

                                sendButton.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        if (oldButton.isSelected()) {
                                            JFrame oldTerrorFrame = new JFrame("Escolha de Terror: Mais antigo");
                                            oldTerrorFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                            oldTerrorFrame.setSize(600, 300);

                                            JPanel oldTerrorPanel = new JPanel(new BorderLayout());
                                            oldTerrorFrame.add(oldTerrorPanel);

                                            JLabel questionLabel = new JLabel("Você prefere filmes de terror mais antigos bem avaliados (IMDb alto)?", SwingConstants.CENTER); //caso nao selecionado as opções, sera considerado o valor "Sim"
                                            oldTerrorPanel.add(questionLabel, BorderLayout.NORTH);

                                            ButtonGroup oldTerrorGroup = new ButtonGroup();
                                            JRadioButton yesButton = new JRadioButton("Sim");
                                            JRadioButton dontMindButton = new JRadioButton("Não me importo");
                                            oldTerrorGroup.add(yesButton);
                                            oldTerrorGroup.add(dontMindButton);

                                            JPanel radioPanel = new JPanel();
                                            radioPanel.add(yesButton);
                                            radioPanel.add(dontMindButton);

                                            oldTerrorPanel.add(radioPanel, BorderLayout.CENTER);

                                            JButton sendButton = new JButton("Enviar");
                                            oldTerrorPanel.add(sendButton, BorderLayout.SOUTH);

                                            oldTerrorFrame.setLocationRelativeTo(null);
                                            oldTerrorFrame.setVisible(true);

                                            terrorFrame.dispose();

                                            sendButton.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    JFrame recommendFrame = new JFrame("Recomendação de Terror Antigo");
                                                    recommendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                    recommendFrame.setSize(700, 400);

                                                    JPanel recommendPanel = new JPanel(new BorderLayout());
                                                    recommendFrame.add(recommendPanel);

                                                    String[] oldTerrorList = {"O Exorcista", "O Iluminado", "Alien, o Oitavo Passageiro", "Nosferatu", "A Noite dos Mortos-Vivos", "O Bebê de Rosemary", "Invasores de Corpos", "Halloween"};
                                                    String[] oldTerrorSynopsis = {
                                                            "Uma atriz vai gradativamente tomando consciência de que a sua filha de doze anos está tendo um comportamento completamente assustador. Deste modo, ela pede ajuda a um padre, que também é um psiquiatra, e este chega a conclusão de que a garota está possuída pelo demônio. Ele solicita então a ajuda de um segundo sacerdote, especialista em exorcismo, para tentar livrar a menina desta terrível possessão.",
                                                            "Jack Torrance se torna caseiro de inverno do isolado Hotel Overlook, nas montanhas do Colorado, na esperança de curar seu bloqueio de escritor. Ele se instala com a esposa Wendy e o filho Danny, que é atormentando por premonições. Jack não consegue escrever e as visões de Danny se tornam mais perturbadoras. O escritor descobre os segredos sombrios do hotel e começa a se transformar em um maníaco homicida, aterrorizando sua família.",
                                                            "Uma nave espacial, ao retornar para Terra, recebe estranhos sinais vindos de um asteroide. Enquanto a equipe investiga o local, um dos tripulantes é atacado por um misterioso ser. O que parecia ser um ataque isolado se transforma em um terror constante, pois o tripulante atacado levou para dentro da nave o embrião de um alienígena, que não para de crescer e tem como meta matar toda a tripulação.",
                                                            "O corretor de imóveis Hutter precisa vender um castelo cujo proprietário é o excêntrico conde Graf Orlock. O conde, na verdade, é um vampiro milenar que espalha o terror na região de Bremen, na Alemanha e se interessa por Ellen, a mulher de Hutter.",
                                                            "Um grupo pessoas se refugia em uma casa abandonada quando cadáveres voltam à vida e tentam devorar os vivos. O pragmático Ben faz o possível para controlar a situação, mas quando os zumbis cercam o local, os outros sobreviventes entram em pânico.",
                                                            "Um casal se muda para um prédio com pessoas estranhas. Acontecimentos ainda mais estranhos levam a jovem, que está grávida, a duvidar de sua própria sanidade. Porém, o parto e a descoberta de uma seita diabólica irão finalmente mostrar a verdade.",
                                                            "Matthew Bennell ouve a amiga reclamar que o marido anda se comportando estranhamente, mas acredita que sejam apenas problemas conjugais. Porém, ele fica preocupado quando outras pessoas começam a fazer as mesmas observações. Sua desconfiança é confirmada quando um escritor e sua esposa encontram um corpo de um mutante. Diante de um inimigo invisível, Matthew deve agir rapidamente antes que toda a cidade seja atingida.",
                                                            "Na noite de Halloween, Michael Myers, um assassino, foge do hospital psiquiátrico onde passou quinze anos internado por ter matado sua irmã. Ele volta a sua cidade natal com intuito de matar novamente."
                                                    };
                                                    /*String[] oldTerrorImages = {"..\\spec\\movies\\terror\\antigos\\oexorcista.jpg", "..\\spec\\movies\\terror\\antigos\\oiluminado.jpg", "..\\spec\\movies\\terror\\antigos\\alien.jpg", "..\\spec\\movies\\terror\\antigos\\nosferatu.jpg", "..\\spec\\movies\\terror\\antigos\\anoitedosmortosvivos.jpg", "..\\spec\\movies\\terror\\antigos\\obebederosemary.jpg", "..\\spec\\movies\\terror\\antigos\\invasoresdecorpos.jpg", "..\\spec\\movies\\terror\\antigos\\halloween.jpg"};*/
                                                    String[] movieImages = {
                                                                "/movies/terror/antigos/oexorcista.jpg",
                                                                "/movies/terror/antigos/oiluminado.jpg",
                                                                "/movies/terror/antigos/alien.jpg",
                                                                "/movies/terror/antigos/nosferatu.jpg",
                                                                "/movies/terror/antigos/anoitedosmortosvivos.jpg",
                                                                "/movies/terror/antigos/obebederosemary.jpg",
                                                                "/movies/terror/antigos/invasoresdecorpos.jpg",
                                                                "/movies/terror/antigos/halloween.jpg"
                                                    };

                                                    Random rand = new Random();
                                                    int randomIndex = rand.nextInt(oldTerrorList.length);

                                                    JLabel recommendLabel = new JLabel("Sugerimos com muito cuidado este filme para você assistir:", SwingConstants.CENTER);
                                                    recommendPanel.add(recommendLabel, BorderLayout.NORTH);

                                                    JLabel terrorLabel = new JLabel(oldTerrorList[randomIndex], SwingConstants.CENTER);
                                                    recommendPanel.add(terrorLabel, BorderLayout.WEST);

                                                    JTextArea terrorSynopsisArea = new JTextArea(oldTerrorSynopsis[randomIndex]);
                                                    terrorSynopsisArea.setLineWrap(true);
                                                    terrorSynopsisArea.setWrapStyleWord(true);
                                                    terrorSynopsisArea.setEditable(false);
                                                    recommendPanel.add(terrorSynopsisArea, BorderLayout.CENTER);

                                                    try {
                                                        URL movieImageUrl = getClass().getResource(movieImages[randomIndex]);
                                                        BufferedImage movieImage = ImageIO.read(movieImageUrl);
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    /*
                                                    try {
                                                        BufferedImage terrorImage = ImageIO.read(new File(oldTerrorImages[randomIndex]));
                                                        JLabel picLabel = new JLabel(new ImageIcon(terrorImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    */

                                                    recommendFrame.setLocationRelativeTo(null);
                                                    recommendFrame.setVisible(true);

                                                    oldTerrorFrame.dispose();
                                                }
                                            });
                                        }
                                        else if (newButton.isSelected()) {
                                            JFrame newTerrorFrame = new JFrame("Escolha de Terror: Mais recente");
                                            newTerrorFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                            newTerrorFrame.setSize(600, 300);

                                            JPanel newTerrorPanel = new JPanel(new BorderLayout());
                                            newTerrorFrame.add(newTerrorPanel);

                                            JLabel questionLabel = new JLabel("Você prefere filmes de terror mais recentes bem avaliados (IMDb alto)?", SwingConstants.CENTER); //caso nao selecionado as opções, sera considerado o valor "Sim"
                                            newTerrorPanel.add(questionLabel, BorderLayout.NORTH);

                                            ButtonGroup newTerrorGroup = new ButtonGroup();
                                            JRadioButton yesButton = new JRadioButton("Sim");
                                            JRadioButton dontMindButton = new JRadioButton("Não me importo");
                                            newTerrorGroup.add(yesButton);
                                            newTerrorGroup.add(dontMindButton);

                                            JPanel radioPanel = new JPanel();
                                            radioPanel.add(yesButton);
                                            radioPanel.add(dontMindButton);

                                            newTerrorPanel.add(radioPanel, BorderLayout.CENTER);

                                            JButton sendButton = new JButton("Enviar");
                                            newTerrorPanel.add(sendButton, BorderLayout.SOUTH);

                                            newTerrorFrame.setLocationRelativeTo(null);
                                            newTerrorFrame.setVisible(true);

                                            terrorFrame.dispose();

                                            sendButton.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    JFrame recommendFrame = new JFrame("Recomendação de Terror Recente");
                                                    recommendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                    recommendFrame.setSize(700, 400);

                                                    JPanel recommendPanel = new JPanel(new BorderLayout());
                                                    recommendFrame.add(recommendPanel);

                                                    String[] terrorList = {"Hereditário", "Corra!", "Um Lugar Silencioso", "O Farol", "Midsommar: O Mal Não Espera a Noite", "It: A Coisa", "Nós", "A Morte do Demônio"};
                                                    String[] terrorSynopsis = {
                                                            "Após a morte da reclusa avó, a família Graham começa a desvendar algumas coisas. Mesmo após a partida da matriarca, ela permanece como se fosse uma sombra sobre a família, especialmente sobre a solitária neta adolescente, Charlie, por quem ela sempre manteve uma fascinação não usual. Com um crescente terror tomando conta da casa, a família explora lugares mais escuros para escapar do infeliz destino que herdaram.",
                                                            "Chris é um jovem fotógrafo negro que está prestes a conhecer os pais de Rose, sua namorada caucasiana. Na luxuosa propriedade dos pais dela, Chris percebe que a família esconde algo muito perturbador.",
                                                            "Em uma fazenda nos Estados Unidos, uma família do Meio-Oeste é perseguida por uma entidade fantasmagórica assustadora. Para se protegerem, eles devem permanecer em silêncio absoluto, a qualquer custo, pois o perigo é ativado pela percepção do som.",
                                                            "No final do século 19, um novo zelador chega a uma remota ilha na Nova Inglaterra para ajudar o faroleiro local, mas o isolamento causa tensão na convivência entre os dois homens. Entre tempestades e goles de querosene, o novato tenta desvendar os mistérios que existem nas histórias de pescador de seu chefe.",
                                                            "Após vivenciar uma tragédia pessoal, Dani vai com o namorado Christian e um grupo de amigos até a Suécia para participar de um festival local de verão. Mas, ao invés das férias tranquilas com a qual todos sonhavam, o grupo se depara com rituais bizarros de uma adoração pagã.",
                                                            "Um grupo de crianças se une para investigar o misterioso desaparecimento de vários jovens em sua cidade. Eles descobrem que o culpado é Pennywise, um palhaço cruel que se alimenta de seus medos e cuja violência teve origem há vários séculos.",
                                                            "Adelaide e Gabe levam a família para passar um fim de semana na praia e descansar. Eles começam a aproveitar o ensolarado local, mas a chegada de um grupo misterioso muda tudo e a família se torna refém de seres com aparências iguais às suas.",
                                                            "Uma mulher se encontra em uma luta por sua vida quando um livro antigo dá à luz demônios sedentos por sangue. Eles se tornam cada vez mais agressivos em um prédio em Los Angeles."
                                                    };
                                                    /*String[] terrorImages = {"..\\spec\\movies\\terror\\recentes\\hereditario.jpg", "..\\spec\\movies\\terror\\recentes\\corra.jpg", "..\\spec\\movies\\terror\\recentes\\umlugarsilencioso.jpg", "..\\spec\\movies\\terror\\recentes\\ofarol.jpg", "..\\spec\\movies\\terror\\recentes\\midsommar.jpg", "..\\spec\\movies\\terror\\recentes\\itacoisa.jpg", "..\\spec\\movies\\terror\\recentes\\nos.jpg", "..\\spec\\movies\\terror\\recentes\\amortedodemonio.jpg"};*/
                                                    String[] movieImages = {
                                                                "/movies/terror/recentes/hereditario.jpg",
                                                                "/movies/terror/recentes/corra.jpg",
                                                                "/movies/terror/recentes/umlugarsilencioso.jpg",
                                                                "/movies/terror/recentes/ofarol.jpg",
                                                                "/movies/terror/recentes/midsommar.jpg",
                                                                "/movies/terror/recentes/itacoisa.jpg",
                                                                "/movies/terror/recentes/nos.jpg",
                                                                "/movies/terror/recentes/amortedodemonio.jpg",
                                                    };

                                                    Random rand = new Random();
                                                    int randomIndex = rand.nextInt(terrorList.length);

                                                    JLabel recommendLabel = new JLabel("Sugerimos que assista este filme: ", SwingConstants.CENTER);
                                                    recommendPanel.add(recommendLabel, BorderLayout.NORTH);

                                                    JLabel terrorLabel = new JLabel(terrorList[randomIndex], SwingConstants.CENTER);
                                                    recommendPanel.add(terrorLabel, BorderLayout.WEST);

                                                    JTextArea terrorSynopsisArea = new JTextArea(terrorSynopsis[randomIndex]);
                                                    terrorSynopsisArea.setLineWrap(true);
                                                    terrorSynopsisArea.setWrapStyleWord(true);
                                                    terrorSynopsisArea.setEditable(false);
                                                    recommendPanel.add(terrorSynopsisArea, BorderLayout.CENTER);

                                                    try {
                                                        URL movieImageUrl = getClass().getResource(movieImages[randomIndex]);
                                                        BufferedImage movieImage = ImageIO.read(movieImageUrl);
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    /*
                                                    try {
                                                        BufferedImage terrorImage = ImageIO.read(new File(terrorImages[randomIndex]));
                                                        JLabel picLabel = new JLabel(new ImageIcon(terrorImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    */

                                                    recommendFrame.setLocationRelativeTo(null);
                                                    recommendFrame.setVisible(true);

                                                    newTerrorFrame.dispose();
                                                }
                                            });
                                        }
                                    }
                                });
                            } else if (selectedGenre.equals("Ficção Científica")) {
                                JFrame scifiFrame = new JFrame("Gênero Escolhido: Ficção Científica");
                                scifiFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                scifiFrame.setSize(600, 300);

                                JPanel scifiPanel = new JPanel(new BorderLayout());
                                scifiFrame.add(scifiPanel);

                                JLabel questionLabel = new JLabel("Você prefere filmes de Ficção Científica mais antigos ? ou mais recentes ?", SwingConstants.CENTER);
                                scifiPanel.add(questionLabel, BorderLayout.NORTH);

                                ButtonGroup scifiGroup = new ButtonGroup();
                                JRadioButton oldButton = new JRadioButton("Mais antigo");
                                JRadioButton newButton = new JRadioButton("Mais recente");
                                scifiGroup.add(oldButton);
                                scifiGroup.add(newButton);

                                JPanel radioPanel = new JPanel();
                                radioPanel.add(oldButton);
                                radioPanel.add(newButton);

                                scifiPanel.add(radioPanel, BorderLayout.CENTER);

                                JButton sendButton = new JButton("Enviar");
                                scifiPanel.add(sendButton, BorderLayout.SOUTH);

                                scifiFrame.setLocationRelativeTo(null);
                                scifiFrame.setVisible(true);

                                genreFrame.dispose();

                                sendButton.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        if (oldButton.isSelected()) {
                                            JFrame oldScifiFrame = new JFrame("Escolha de Ficção Científica: Mais antigo");
                                            oldScifiFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                            oldScifiFrame.setSize(600, 300);

                                            JPanel oldScifiPanel = new JPanel(new BorderLayout());
                                            oldScifiFrame.add(oldScifiPanel);

                                            JLabel questionLabel = new JLabel("Você prefere filmes de Ficção Científica mais antigos bem avaliados (IMDb alto)?", SwingConstants.CENTER); //caso nao selecionado as opções, sera considerado o valor "Sim"
                                            oldScifiPanel.add(questionLabel, BorderLayout.NORTH);

                                            ButtonGroup oldScifiGroup = new ButtonGroup();
                                            JRadioButton yesButton = new JRadioButton("Sim");
                                            JRadioButton dontMindButton = new JRadioButton("Não me importo");
                                            oldScifiGroup.add(yesButton);
                                            oldScifiGroup.add(dontMindButton);

                                            JPanel radioPanel = new JPanel();
                                            radioPanel.add(yesButton);
                                            radioPanel.add(dontMindButton);

                                            oldScifiPanel.add(radioPanel, BorderLayout.CENTER);

                                            JButton sendButton = new JButton("Enviar");
                                            oldScifiPanel.add(sendButton, BorderLayout.SOUTH);

                                            oldScifiFrame.setLocationRelativeTo(null);
                                            oldScifiFrame.setVisible(true);

                                            scifiFrame.dispose();

                                            sendButton.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    JFrame recommendFrame = new JFrame("Recomendação de Ficção Científica Antiga");
                                                    recommendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                    recommendFrame.setSize(700, 400);

                                                    JPanel recommendPanel = new JPanel(new BorderLayout());
                                                    recommendFrame.add(recommendPanel);

                                                    String[] scifiList = {"2001: Uma Odisseia no Espaço", "Blade Runner", "Guerra nas Estrelas", "O Planeta dos Macacos", "O Dia em que a Terra Parou", "E.T. - O Extraterrestre", "O Exterminador do Futuro 2"};
                                                    String[] scifiSynopsis = {
                                                            "Uma estrutura imponente preta fornece uma conexão entre o passado e o futuro nesta adaptação enigmática de um conto reverenciado de ficção científica do autor Arthur C. Clarke. Quando o Dr. Dave Bowman e outros astronautas são enviados para uma misteriosa missão, os chips de seus computadores começam a mostrar um comportamento estranho, levando a um tenso confronto entre homem e máquina que resulta em uma viagem alucinante no espaço e no tempo.",
                                                            "Em um futuro distópico de 2019, caçadores de recompensa chamados 'Blade Runners' são encarregados de 'aposentar' replicantes, androides humanóides, que ameaçam a ordem social.",
                                                            "O malévolo Darth Vader, braço direito do imperador, está em busca dos planos da Estrela da Morte, uma estação espacial com capacidade para destruir um planeta. Luke Skywalker se junta a Han Solo, um piloto espacial, e Obi-Wan Kenobi, para garantir que a Princesa Leia Organa receba os planos, que revelam a maneira de destruir a estação espacial.",
                                                            "Depois de sofrer um acidente com sua espaçonave, Leo Davidson consegue chegar a um planeta diferente, aparentemente cruel, onde seres humanos são caçados e escravizados por primatas e têm de se esforçar muito para conquistar seus meios de subsistência. Ao ver tudo aquilo, Leo fica indignado com a opressão imposta aos humanos. Ele logo propõe uma revolução, tornando-se uma enorme ameaça ao status quo do planeta.",
                                                            "Um alienígena chamado Klaatu atravessa o universo para chegar à Terra e avisar os humanos sobre uma crise global que está por vir. Ele encontra a renomada cientista Dra. Helen Benson, que, juntamente com seu filho Jacob, deve proteger o alienígena amigo da Terra.",
                                                            "O garoto Elliott faz amizade com um pequeno alienígena inofensivo que está bem longe do seu planeta. Ele decide manter a adorável criatura em segredo e em casa após apresentá-la aos irmãos.",
                                                            "O jovem John Connor é a chave para a vitória da civilização sobre uma rebelião de robôs do futuro. No entanto, ele torna-se alvo de T-1000, um exterminador que pode assumir a forma que desejar e que foi enviado do futuro para matá-lo. Outro exterminador, o renovado T-800, também é enviado de volta ao passado para proteger o menino. Quando John e sua mãe embarcam na fuga com T-800, o menino cria um vínculo forte e inesperado com o robô."
                                                    };
                                                    /*String[] scifiImages = {"..\\spec\\movies\\ficcao\\antigos\\2001odisseia.jpg", "..\\spec\\movies\\ficcao\\antigos\\bladerunner.jpg", "..\\spec\\movies\\ficcao\\antigos\\guerranasestrelas.jpg", "..\\spec\\movies\\ficcao\\antigos\\planetamacacos.jpg", "..\\spec\\movies\\ficcao\\antigos\\diaterraparou.jpg", "..\\spec\\movies\\ficcao\\antigos\\et.jpg", "..\\spec\\movies\\ficcao\\antigos\\exterminador.jpg"};*/
                                                    String[] movieImages = {
                                                                "/movies/ficcao/antigos/2001odisseia.jpg",
                                                                "/movies/ficcao/antigos/bladerunner.jpg",
                                                                "/movies/ficcao/antigos/guerranasestrelas.jpg",
                                                                "/movies/ficcao/antigos/planetamacacos.jpg",
                                                                "/movies/ficcao/antigos/diaterraparou.jpg",
                                                                "/movies/ficcao/antigos/et.jpg",
                                                                "/movies/ficcao/antigos/exterminador.jpg"
                                                    };

                                                    Random rand = new Random();
                                                    int randomIndex = rand.nextInt(scifiList.length);

                                                    JLabel recommendLabel = new JLabel("Sugerimos que assista este filme: ", SwingConstants.CENTER);
                                                    recommendPanel.add(recommendLabel, BorderLayout.NORTH);

                                                    JLabel scifiLabel = new JLabel(scifiList[randomIndex], SwingConstants.CENTER);
                                                    recommendPanel.add(scifiLabel, BorderLayout.WEST);

                                                    JTextArea scifiSynopsisArea = new JTextArea(scifiSynopsis[randomIndex]);
                                                    scifiSynopsisArea.setLineWrap(true);
                                                    scifiSynopsisArea.setWrapStyleWord(true);
                                                    scifiSynopsisArea.setEditable(false);
                                                    recommendPanel.add(scifiSynopsisArea, BorderLayout.CENTER);

                                                    try {
                                                        URL movieImageUrl = getClass().getResource(movieImages[randomIndex]);
                                                        BufferedImage movieImage = ImageIO.read(movieImageUrl);
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    /*
                                                    try {
                                                        BufferedImage scifiImage = ImageIO.read(new File(scifiImages[randomIndex]));
                                                        JLabel picLabel = new JLabel(new ImageIcon(scifiImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    */

                                                    recommendFrame.setLocationRelativeTo(null);
                                                    recommendFrame.setVisible(true);

                                                    oldScifiFrame.dispose();
                                                }
                                            });
                                        }
                                        else if (newButton.isSelected()) {
                                            JFrame newScifiFrame = new JFrame("Escolha de Ficção Científica: Mais recente");
                                            newScifiFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                            newScifiFrame.setSize(600, 300);

                                            JPanel newScifiPanel = new JPanel(new BorderLayout());
                                            newScifiFrame.add(newScifiPanel);

                                            JLabel questionLabel = new JLabel("Você prefere filmes de Ficção Científica mais recentes bem avaliados (IMDb alto)?", SwingConstants.CENTER); //caso nao selecionado as opções, sera considerado o valor "Sim"
                                            newScifiPanel.add(questionLabel, BorderLayout.NORTH);

                                            ButtonGroup newScifiGroup = new ButtonGroup();
                                            JRadioButton yesButton = new JRadioButton("Sim");
                                            JRadioButton dontMindButton = new JRadioButton("Não me importo");
                                            newScifiGroup.add(yesButton);
                                            newScifiGroup.add(dontMindButton);

                                            JPanel radioPanel = new JPanel();
                                            radioPanel.add(yesButton);
                                            radioPanel.add(dontMindButton);

                                            newScifiPanel.add(radioPanel, BorderLayout.CENTER);

                                            JButton sendButton = new JButton("Enviar");
                                            newScifiPanel.add(sendButton, BorderLayout.SOUTH);

                                            newScifiFrame.setLocationRelativeTo(null);
                                            newScifiFrame.setVisible(true);

                                            scifiFrame.dispose();

                                            sendButton.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    JFrame recommendFrame = new JFrame("Recomendação de Ficção Científica Recente");
                                                    recommendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                    recommendFrame.setSize(700, 400);

                                                    JPanel recommendPanel = new JPanel(new BorderLayout());
                                                    recommendFrame.add(recommendPanel);

                                                    String[] scifiList = {"Interstellar", "Blade Runner 2049", "Ad Astra: Rumo às Estrelas", "Mad Max: Estrada da Fúria", "Jurassic World: O Mundo dos Dinossauros", "Avatar", "Dune", "Matrix Resurrections"};
                                                    String[] scifiSynopsis = {
                                                            "As reservas naturais da Terra estão chegando ao fim e um grupo de astronautas recebe a missão de verificar possíveis planetas para receberem a população mundial, possibilitando a continuação da espécie. Cooper é chamado para liderar o grupo e aceita a missão sabendo que pode nunca mais ver os filhos. Ao lado de Brand, Jenkins e Doyle, ele seguirá em busca de um novo lar.",
                                                            "Após descobrir um segredo que ameaça o que resta da sociedade, um novo policial parte em busca de Rick Deckard, que está desaparecido há 30 anos.",
                                                            "Um homem viaja pelo interior de um sistema solar sem lei para encontrar seu pai desaparecido, um cientista renegado que representa uma ameaça à humanidade.",
                                                            "Em um mundo pós-apocalíptico, Max Rockatansky acredita que a melhor forma de sobreviver é não depender de ninguém. Porém, após ser capturado pelo tirano Immortan Joe e seus rebeldes, Max se vê no meio de uma guerra mortal iniciada pela Imperatriz Furiosa, que tenta salvar um grupo de garotas. Também tentando fugir, Max aceita ajudá-la.",
                                                            "O Parque dos Dinossauros está aberto para visitação, e o público tem a chance de ver de perto as mais diversas espécies. Porém, um desses animais, resultado de experiência genética, desenvolve alta inteligência e se torna uma ameaça para todos.",
                                                            "No exuberante mundo alienígena de Pandora vivem os Na'vi, seres que parecem ser primitivos, mas são altamente evoluídos. Como o ambiente do planeta é tóxico, foram criados os avatares, corpos biológicos controlados pela mente humana que se movimentam livremente em Pandora. Jake Sully, um ex-fuzileiro naval paralítico, volta a andar através de um avatar e se apaixona por uma Na'vi. Esta paixão leva Jake a lutar pela sobrevivência de Pandora.",
                                                            "Paul Atreides é um jovem brilhante, dono de um destino além de sua compreensão. Ele deve viajar para o planeta mais perigoso do universo para garantir o futuro de seu povo.",
                                                            "Se o Sr. Anderson, conhecido como Neo, aprendeu alguma coisa é que a escolha, mesmo sendo uma ilusão, é a única maneira de sair - ou entrar - da Matrix. Ele sabe o que precisa fazer, mas ainda não descobriu que a Matrix está mais forte e perigosa."
                                                    };
                                                    /*String[] scifiImages = {"..\\spec\\movies\\ficcao\\recentes\\interstellar.jpg", "..\\spec\\movies\\ficcao\\recentes\\bladerunner2049.jpg", "..\\spec\\movies\\ficcao\\recentes\\adastra.jpg", "..\\spec\\movies\\ficcao\\recentes\\madmax.jpg", "..\\spec\\movies\\ficcao\\recentes\\jurassicworld.jpg", "..\\spec\\movies\\ficcao\\recentes\\avatar.jpg", "..\\spec\\movies\\ficcao\\recentes\\dune.jpg", "..\\spec\\movies\\ficcao\\recentes\\matrixresurrections.jpg"};*/
                                                    String[] movieImages = {
                                                                "/movies/ficcao/recentes/interstellar.jpg",
                                                                "/movies/ficcao/recentes/bladerunner2049.jpg",
                                                                "/movies/ficcao/recentes/adastra.jpg",
                                                                "/movies/ficcao/recentes/madmax.jpg",
                                                                "/movies/ficcao/recentes/jurassicworld.jpg",
                                                                "/movies/ficcao/recentes/avatar.jpg",
                                                                "/movies/ficcao/recentes/dune.jpg",
                                                                "/movies/ficcao/recentes/matrixresurrections.jpg"
                                                        };

                                                    Random rand = new Random();
                                                    int randomIndex = rand.nextInt(scifiList.length);

                                                    JLabel recommendLabel = new JLabel("Sugerimos que assista este filme: ", SwingConstants.CENTER);
                                                    recommendPanel.add(recommendLabel, BorderLayout.NORTH);

                                                    JLabel scifiLabel = new JLabel(scifiList[randomIndex], SwingConstants.CENTER);
                                                    recommendPanel.add(scifiLabel, BorderLayout.WEST);

                                                    JTextArea scifiSynopsisArea = new JTextArea(scifiSynopsis[randomIndex]);
                                                    scifiSynopsisArea.setLineWrap(true);
                                                    scifiSynopsisArea.setWrapStyleWord(true);
                                                    scifiSynopsisArea.setEditable(false);
                                                    recommendPanel.add(scifiSynopsisArea, BorderLayout.CENTER);

                                                    try {
                                                        URL movieImageUrl = getClass().getResource(movieImages[randomIndex]);
                                                        BufferedImage movieImage = ImageIO.read(movieImageUrl);
                                                        JLabel picLabel = new JLabel(new ImageIcon(movieImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    /*
                                                    try {
                                                        BufferedImage scifiImage = ImageIO.read(new File(scifiImages[randomIndex]));
                                                        JLabel picLabel = new JLabel(new ImageIcon(scifiImage));
                                                        recommendPanel.add(picLabel, BorderLayout.EAST);
                                                    } catch (IOException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    */

                                                    recommendFrame.setLocationRelativeTo(null);
                                                    recommendFrame.setVisible(true);

                                                    newScifiFrame.dispose();
                                                }
                                            });
                                        }
                                    }
                                });
                            } else {
                                // Aqui continua a logica para outros generos de filmes.
                            }
                        } else {
                            // Se o usuário não selecionar um genero
                        }
                    }
                });
            }
        });
    }
}